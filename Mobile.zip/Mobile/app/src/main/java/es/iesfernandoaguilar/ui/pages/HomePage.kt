package es.iesfernandoaguilar.ui.pages

import android.annotation.SuppressLint
import android.graphics.BitmapFactory
import androidx.annotation.StringRes
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.models.Class
import es.iesfernandoaguilar.models.Club
import es.iesfernandoaguilar.models.EnrollmentRequest
import es.iesfernandoaguilar.models.Request
import es.iesfernandoaguilar.models.objects.SessionData
import es.iesfernandoaguilar.ui.ScreenType
import es.iesfernandoaguilar.ui.components.AppBar
import es.iesfernandoaguilar.ui.navigation.Destination
import es.iesfernandoaguilar.ui.viewmodel.HomeState
import es.iesfernandoaguilar.ui.viewmodel.HomeUiStateClass
import es.iesfernandoaguilar.ui.viewmodel.HomeUiStateClub
import es.iesfernandoaguilar.ui.viewmodel.HomeUiStateEnrollmentRequest
import es.iesfernandoaguilar.ui.viewmodel.HomeUiStatePublicClasses
import es.iesfernandoaguilar.ui.viewmodel.HomeUiStateRequest
import es.iesfernandoaguilar.ui.viewmodel.HomeViewModel
import es.iesfernandoaguilar.utils.QRUtils
import org.json.JSONObject
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle

object HomeDestination : Destination {
    override val route = "home"
    override val titleRes = R.string.main_page
}

@Composable
fun HomePage(
    viewModel: HomeViewModel = hiltViewModel(),
    @StringRes title: Int,
    onLogOut: () -> Unit,
    onSettingsPressed: () -> Unit,
    onClubSelected: (Club) -> Unit,
    onClassSelected: (Class) -> Unit,
    screenType: ScreenType
) {
    // UI states
    val homeUiStateClass = viewModel.homeUiStateClass
    val homeUiStateClub = viewModel.homeUiStateClub
    val homeUiStateRequest = viewModel.homeUiStateRequest
    val homeUiStatePublicClasses = viewModel.homeUiStatePublicClasses
    val homeUiStateEnrollmentRequest = viewModel.homeUiStateEnrollmentRequest
    val homeState by viewModel.state.collectAsState()

    // UI flags
    var showQR by remember { mutableStateOf(false) }
    var viewRequests by remember { mutableStateOf(false) }
    var viewEnrollmentRequests by remember { mutableStateOf(false) }
    var viewPublicClasses by remember { mutableStateOf(false) }

    val studentUsername = SessionData.currentUser?.userName ?: ""

    Scaffold(
        topBar = {
            AppBar(
                canGoBack = false,
                titleResId = title,
                actions = {
                    IconButton(onClick = onLogOut) {
                        Icon(
                            Icons.AutoMirrored.Filled.Logout,
                            contentDescription = stringResource(R.string.logout)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    IconButton(onClick = onSettingsPressed) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = stringResource(R.string.settings_page)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    IconButton(onClick = { viewModel.requestData() }) {
                        Icon(
                            Icons.Default.Replay,
                            contentDescription = stringResource(R.string.reload)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            // Show FAB only if data is successfully loaded
            if (homeUiStateClass == HomeUiStateClass.Success && homeUiStateClub == HomeUiStateClub.Success) {
                FloatingActionButton(
                    onClick = { showQR = true },
                    containerColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = stringResource(R.string.show_qr)
                    )
                }
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ) { paddingValues ->

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (screenType) {
                ScreenType.Medium -> {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .fillMaxHeight()
                            .align(Alignment.Center)
                            .padding(24.dp)
                    ) {
                        // Clubs section
                        ClubsSection(
                            homeUiStateRequest,
                            homeUiStateClub,
                            homeState,
                            viewRequests,
                            viewModel,
                            onClubSelected,
                            onToggleRequests = { viewRequests = !viewRequests },
                            modifier = Modifier
                                .padding(24.dp)
                                .weight(1f)
                                .fillMaxSize()
                        )

                        // Classes section
                        ClassesSection(
                            homeUiStateClass,
                            homeUiStatePublicClasses,
                            homeUiStateEnrollmentRequest,
                            homeState,
                            viewEnrollmentRequests,
                            viewPublicClasses,
                            onClassSelected,
                            onToggleEnrollmentRequests = {
                                viewEnrollmentRequests = !viewEnrollmentRequests
                                viewPublicClasses = false
                            },
                            onTogglePublicClasses = {
                                viewPublicClasses = !viewPublicClasses
                                viewEnrollmentRequests = false
                            },
                            viewModel = viewModel,
                            modifier = Modifier
                                .padding(24.dp)
                                .weight(1f)
                                .fillMaxSize()
                        )
                    }
                }
                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Classes on top
                        ClassesSection(
                            homeUiStateClass,
                            homeUiStatePublicClasses,
                            homeUiStateEnrollmentRequest,
                            homeState,
                            viewEnrollmentRequests,
                            viewPublicClasses,
                            onClassSelected,
                            onToggleEnrollmentRequests = {
                                viewEnrollmentRequests = !viewEnrollmentRequests
                                viewPublicClasses = false
                            },
                            onTogglePublicClasses = {
                                viewPublicClasses = !viewPublicClasses
                                viewEnrollmentRequests = false
                            },
                            viewModel = viewModel,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .padding(24.dp)
                        )

                        // Clubs below
                        ClubsSection(
                            homeUiStateRequest,
                            homeUiStateClub,
                            homeState,
                            viewRequests,
                            viewModel,
                            onClubSelected,
                            onToggleRequests = { viewRequests = !viewRequests },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .padding(24.dp)
                        )
                    }
                }
            }

            if (showQR) {
                QRCodeDialog(
                    studentUsername = studentUsername,
                    onDismiss = { showQR = false }
                )
            }
        }
    }
}

@Composable
private fun ClubsSection(
    homeUiStateRequest: HomeUiStateRequest,
    homeUiStateClub: HomeUiStateClub,
    homeState: HomeState,
    viewRequests: Boolean,
    viewModel: HomeViewModel,
    onClubSelected: (Club) -> Unit,
    onToggleRequests: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(
                stringResource(R.string.clubs),
                style = MaterialTheme.typography.headlineMedium
            )
            TextButton(
                onClick = onToggleRequests,
                enabled = homeUiStateRequest is HomeUiStateRequest.Success && homeState.requestList.isNotEmpty()
            ) {
                when (homeUiStateRequest) {
                    is HomeUiStateRequest.Loading -> Text(stringResource(R.string.loading))
                    is HomeUiStateRequest.Success -> {
                        if (homeState.requestList.isNotEmpty()) {
                            Text(stringResource(R.string.have_request, homeState.requestList.size))
                        }
                    }
                }
            }
        }

        when (homeUiStateClub) {
            HomeUiStateClub.Loading -> {
                CircularProgressIndicator(
                    modifier = Modifier
                        .padding(24.dp)
                        .align(Alignment.CenterHorizontally)
                )
            }
            else -> {
                if (viewRequests && homeState.requestList.isNotEmpty()) {
                    LazyColumn {
                        items(homeState.requestList) { request ->
                            RequestCard(
                                request = request,
                                onDecideRequest = { accepted ->
                                    if (accepted) viewModel.acceptRequest(request)
                                    else viewModel.declineRequest(request)
                                }
                            )
                        }
                    }
                } else {
                    LazyColumn {
                        item {
                            homeState.personalClub?.let { personalClub ->
                                ClubCard(
                                    club = personalClub,
                                    onEnterClub = { onClubSelected(personalClub) }
                                )
                            }
                        }
                        items(homeState.clubList) { club ->
                            ClubCard(club, onEnterClub = { onClubSelected(club) })
                        }
                    }
                    if (homeState.personalClub == null && homeState.clubList.isEmpty()) {
                        Text(
                            stringResource(R.string.not_club_inscribed),
                            style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ClassesSection(
    homeUiStateClass: HomeUiStateClass,
    homeUiStatePublicClasses: HomeUiStatePublicClasses,
    homeUiStateEnrollmentRequest: HomeUiStateEnrollmentRequest,
    homeState: HomeState,
    viewEnrollmentRequests: Boolean,
    viewPublicClasses: Boolean,
    onClassSelected: (Class) -> Unit,
    onToggleEnrollmentRequests: () -> Unit,
    onTogglePublicClasses: () -> Unit,
    viewModel: HomeViewModel,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(
                stringResource(R.string.classes),
                style = MaterialTheme.typography.headlineMedium
            )
            TextButton(
                onClick = onTogglePublicClasses,
                enabled = homeUiStatePublicClasses is HomeUiStatePublicClasses.Success && homeState.publicClasses.isNotEmpty()
            ) {
                when (homeUiStatePublicClasses) {
                    is HomeUiStatePublicClasses.Loading -> Text(stringResource(R.string.loading))
                    is HomeUiStatePublicClasses.Success -> {
                        if (homeState.publicClasses.isNotEmpty()) {
                            Text(stringResource(R.string.public_classes_dispo, homeState.publicClasses.size))
                        }
                    }
                }
            }
            TextButton(
                onClick = onToggleEnrollmentRequests,
                enabled = homeUiStateEnrollmentRequest is HomeUiStateEnrollmentRequest.Success && homeState.enrollmentRequestList.isNotEmpty()
            ) {
                when (homeUiStateEnrollmentRequest) {
                    is HomeUiStateEnrollmentRequest.Loading -> Text(stringResource(R.string.loading))
                    is HomeUiStateEnrollmentRequest.Success -> {
                        if (homeState.enrollmentRequestList.isNotEmpty()) {
                            Text(stringResource(R.string.have_request, homeState.enrollmentRequestList.size))
                        }
                    }
                }
            }
        }

        when (homeUiStateClass) {
            HomeUiStateClass.Loading -> {
                CircularProgressIndicator(
                    modifier = Modifier
                        .padding(24.dp)
                        .align(Alignment.CenterHorizontally)
                )
            }
            else -> {
                when {
                    viewEnrollmentRequests && homeState.enrollmentRequestList.isNotEmpty() -> {
                        LazyColumn {
                            items(homeState.enrollmentRequestList) { enrollmentRequest ->
                                EnrollmentRequestCard(
                                    enrollmentRequest,
                                    onDecideRequest = { accepted ->
                                        if (accepted) viewModel.acceptEnrollmentRequest(enrollmentRequest)
                                        else viewModel.declineEnrollmentRequest(enrollmentRequest)
                                    }
                                )
                            }
                        }
                    }
                    viewPublicClasses && homeState.publicClasses.isNotEmpty() -> {
                        LazyColumn {
                            items(homeState.publicClasses) { publicClass ->
                                PublicClassCard(
                                    publicClass,
                                    onJoinClass = { viewModel.joinIntoPublicClass(publicClass) }
                                )
                            }
                        }
                    }
                    else -> {
                        ClassListSection(
                            classList = homeState.classList,
                            finishedClassList = homeState.finishedClasses,
                            onClassSelected = onClassSelected
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ClassListSection(
    classList: List<Class>,
    finishedClassList: List<Class>,
    onClassSelected: (Class) -> Unit,
    limitHeight: Dp = Dp.Unspecified
) {
    var showFinished by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .heightIn(max = limitHeight)
    ) {
        // Active classes or empty message
        if (classList.isEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.not_class_inscribed),
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            items(classList) { clazz ->
                ClassCard(
                    clazz = clazz,
                    onEnterClass = { onClassSelected(clazz) }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }

        // Expandable finished classes section
        if (finishedClassList.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showFinished = !showFinished }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (showFinished) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (showFinished) {
                            stringResource(R.string.collapse_finished_classes)
                        } else {
                            stringResource(R.string.expand_finished_classes)
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.finished_classes),
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }

            if (showFinished) {
                items(finishedClassList) { clazz ->
                    ClassCard(
                        clazz = clazz,
                        onEnterClass = { onClassSelected(clazz) },
                        seeNextSchedule = false
                    )
                }
            }
        }
    }
}

@SuppressLint("LocalContextConfigurationRead")
@Composable
fun EnrollmentRequestCard(
    enrollmentRequest: EnrollmentRequest,
    onDecideRequest: (Boolean) -> Unit
) {
    val clazz = enrollmentRequest.classData
    val context = LocalContext.current
    var isDescriptionExpanded by remember { mutableStateOf(false) }

    // Get locale and date formatter
    val locale = context.resources.configuration.locales[0]
    val dateFormatter = remember { DateTimeFormatter.ofPattern("dd MMMM yyyy", locale) }

    // Format days of week as string
    val daysOfWeek = clazz.weekDays?.joinToString(", ") {
        it.getDisplayName(TextStyle.FULL, locale)
    }

    // Compose schedule text depending on uniqueDate flag
    val scheduleText = if (clazz.uniqueDate) {
        "${clazz.uniqueDateDay!!.format(dateFormatter)} | ${clazz.startTime} - ${clazz.endTime}"
    } else {
        "${clazz.startTime} - ${clazz.endTime} | $daysOfWeek"
    }

    // Format request date
    val requestDate = enrollmentRequest.dateOfRequest.format(dateFormatter)

    BaseCard(onClick = {}) { // Disable card click
        Column(modifier = Modifier.fillMaxWidth()) {

            // Title and club info row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = clazz.name, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = clazz.clubName, style = MaterialTheme.typography.bodyMedium)
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = clazz.instructorName,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.End
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = clazz.roomName,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.End
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Description header
            Text(
                text = stringResource(R.string.description),
                style = MaterialTheme.typography.bodyLarge
            )

            // Expandable description text
            Text(
                text = clazz.description,
                style = MaterialTheme.typography.bodySmall,
                maxLines = if (isDescriptionExpanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isDescriptionExpanded = !isDescriptionExpanded }
            )

            Spacer(modifier = Modifier.height(15.dp))

            // Schedule header
            Text(
                text = stringResource(R.string.schedule),
                style = MaterialTheme.typography.bodyLarge
            )

            // Schedule details
            Text(
                text = scheduleText,
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(15.dp))

            // Request date info
            Text(
                text = "${stringResource(id = R.string.request_date_label)}: $requestDate",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Accept / Reject buttons centered
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = { onDecideRequest(true) }) {
                    Text(text = stringResource(id = R.string.accept))
                }
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(onClick = { onDecideRequest(false) }) {
                    Text(text = stringResource(id = R.string.reject))
                }
            }
        }
    }
}

@Composable
fun RequestCard(request: Request, onDecideRequest: (Boolean) -> Unit) {
    val club = request.club
    var isDescriptionExpanded by remember { mutableStateOf(false) }

    BaseCard(onClick = {}) { // Disable card click, use buttons only
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Show club photo if available
                if (club.havePhoto) {
                    val imageBitmap = remember(club.photo) {
                        BitmapFactory.decodeByteArray(club.photo!!, 0, club.photo!!.size)?.asImageBitmap()
                    }
                    Image(
                        bitmap = imageBitmap!!,
                        contentDescription = stringResource(R.string.club_photo),
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                }

                // Display club name
                Text(
                    text = club.name,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Description header
            Text(
                text = stringResource(R.string.description),
                style = MaterialTheme.typography.bodyLarge,
            )

            // Expandable club description
            Text(
                text = club.description,
                style = MaterialTheme.typography.bodySmall,
                maxLines = if (isDescriptionExpanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isDescriptionExpanded = !isDescriptionExpanded }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Address header
            Text(
                text = stringResource(R.string.address),
                style = MaterialTheme.typography.bodyLarge,
            )

            // Club full address
            Text(
                text = "${club.address} - ${club.city} - ${club.postalCode}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Accept and Reject buttons centered
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = { onDecideRequest(true) }) {
                    Text(text = stringResource(R.string.accept))
                }
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(onClick = { onDecideRequest(false) }) {
                    Text(text = stringResource(R.string.reject))
                }
            }
        }
    }
}

@SuppressLint("LocalContextConfigurationRead")
@Composable
fun PublicClassCard(clazz: Class, onJoinClass: () -> Unit) {
    val context = LocalContext.current
    var isDescriptionExpanded by remember { mutableStateOf(false) }

    // Get current locale and formatter
    val locale = context.resources.configuration.locales[0]
    val dateFormatter = remember { DateTimeFormatter.ofPattern("dd MMMM yyyy", locale) }

    // Format days of week as full names
    val daysOfWeek = clazz.weekDays?.joinToString(", ") {
        it.getDisplayName(TextStyle.FULL, locale)
    }

    // Prepare schedule text depending on uniqueDate flag
    val scheduleText = if (clazz.uniqueDate) {
        "${clazz.uniqueDateDay!!.format(dateFormatter)} | ${clazz.startTime} - ${clazz.endTime}"
    } else {
        "${clazz.startTime} - ${clazz.endTime} | $daysOfWeek"
    }

    BaseCard(onClick = {}) {  // Disable card click, only button active
        Column(modifier = Modifier.fillMaxWidth()) {

            // Header row with class and club info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = clazz.name,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = clazz.clubName,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = clazz.instructorName,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.End
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = clazz.roomName,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.End
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Description title
            Text(
                text = stringResource(R.string.description),
                style = MaterialTheme.typography.bodyLarge
            )

            // Expandable description text
            Text(
                text = clazz.description,
                style = MaterialTheme.typography.bodySmall,
                maxLines = if (isDescriptionExpanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isDescriptionExpanded = !isDescriptionExpanded }
            )

            Spacer(modifier = Modifier.height(15.dp))

            // Schedule title
            Text(
                text = stringResource(R.string.schedule),
                style = MaterialTheme.typography.bodyLarge
            )

            // Schedule details
            Text(
                text = scheduleText,
                style = MaterialTheme.typography.bodySmall
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Join class button centered
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = onJoinClass) {
                    Text(text = stringResource(R.string.request_join))
                }
            }
        }
    }
}

@Composable
fun ClubCard(club: Club, onEnterClub: () -> Unit) {
    var isDescriptionExpanded by remember { mutableStateOf(false) }

    BaseCard(onClick = onEnterClub) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Load and show club photo if available
                if (club.havePhoto) {
                    val imageBitmap = remember(club.photo) {
                        club.photo?.let {
                            BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap()
                        }
                    }
                    imageBitmap?.let {
                        Image(
                            bitmap = it,
                            contentDescription = stringResource(R.string.club_photo),
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                    }
                }

                // Display club name with weight to fill remaining space
                Text(
                    text = club.name,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = stringResource(R.string.description),
                style = MaterialTheme.typography.bodyLarge
            )

            // Expandable description text on click
            Text(
                text = club.description,
                style = MaterialTheme.typography.bodySmall,
                maxLines = if (isDescriptionExpanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isDescriptionExpanded = !isDescriptionExpanded }
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = stringResource(R.string.address),
                style = MaterialTheme.typography.bodyLarge
            )

            // Display full address info
            Text(
                text = "${club.address} - ${club.city} - ${club.postalCode}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@SuppressLint("LocalContextConfigurationRead")
@Composable
fun ClassCard(
    clazz: Class,
    onEnterClass: () -> Unit,
    seeNextSchedule: Boolean = true
) {
    val context = LocalContext.current
    var isDescriptionExpanded by remember { mutableStateOf(false) }

    val locale = context.resources.configuration.locales[0]
    val dateFormatter = remember(locale) { DateTimeFormatter.ofPattern("dd MMMM yyyy", locale) }

    val now = rememberUpdatedState(ZonedDateTime.now())

    // Calculate next class date/time based on uniqueDate or weekly schedule
    val nextClassDateTime = remember(clazz, now.value) {
        if (clazz.uniqueDate) {
            clazz.uniqueDateDay!!.atTime(clazz.startTime).atZone(ZoneId.systemDefault())
        } else {
            val today = now.value.toLocalDate()
            val currentDayOfWeek = now.value.dayOfWeek
            clazz.weekDays!!
                .map { dayOfWeek ->
                    var diff = dayOfWeek.value - currentDayOfWeek.value
                    if (diff < 0 || (diff == 0 && now.value.toLocalTime() >= clazz.startTime)) diff += 7
                    today.plusDays(diff.toLong()).atTime(clazz.startTime)
                }
                .minByOrNull { it.atZone(ZoneId.systemDefault()) }!!
                .atZone(ZoneId.systemDefault())
        }
    }

    // Calculate duration until next class
    val durationUntilNext = Duration.between(now.value, nextClassDateTime)
    val timeUntilText = if (durationUntilNext.isNegative) {
        stringResource(R.string.class_already_started)
    } else {
        val hours = durationUntilNext.toHours()
        val minutes = durationUntilNext.toMinutes() % 60
        "${hours}h ${minutes}m"
    }

    // Format days of week as a string
    val daysOfWeek = clazz.weekDays?.joinToString(", ") { it.getDisplayName(TextStyle.FULL, locale) }

    // Compose schedule text depending on uniqueDate or recurring days
    val scheduleText = if (clazz.uniqueDate) {
        "${clazz.uniqueDateDay!!.format(dateFormatter)} | ${clazz.startTime} - ${clazz.endTime}"
    } else {
        "${clazz.startTime} - ${clazz.endTime} | $daysOfWeek"
    }

    BaseCard(onClick = onEnterClass) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header with class and instructor info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = clazz.name, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = clazz.clubName, style = MaterialTheme.typography.bodyMedium)
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(text = clazz.instructorName, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.End)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = clazz.roomName, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.End)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(text = stringResource(R.string.description), style = MaterialTheme.typography.bodyLarge)

            // Description with expand/collapse on click
            Text(
                text = clazz.description,
                style = MaterialTheme.typography.bodySmall,
                maxLines = if (isDescriptionExpanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isDescriptionExpanded = !isDescriptionExpanded }
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(text = stringResource(R.string.schedule), style = MaterialTheme.typography.bodyLarge)
            Text(text = scheduleText, style = MaterialTheme.typography.bodySmall)

            Spacer(modifier = Modifier.height(15.dp))

            // Show time until next class if enabled
            if (seeNextSchedule) {
                Text(
                    text = stringResource(R.string.next_class_in),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = timeUntilText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}


// Basic clickable card with padding and animated content size
@Composable
fun BaseCard(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable(onClick = onClick) // Make entire card clickable
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .animateContentSize() // Smooth size changes when content changes
                .padding(15.dp)
        ) {
            content()
        }
    }
}

// Dialog displaying a QR code generated from student username and current timestamp
@SuppressLint("RememberReturnType")
@Composable
fun QRCodeDialog(studentUsername: String, onDismiss: () -> Unit) {
    // JSON content for QR code - memoized for performance
    val qrContent = remember {
        JSONObject().apply {
            put("studentUsername", studentUsername)
            put("dateTime", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME))
        }.toString()
    }

    // Generate QR bitmap from content, recomputed only if content changes
    val qrBitmap = remember(qrContent) { QRUtils.generateQRCode(qrContent) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.close))
            }
        },
        title = { Text(stringResource(R.string.student_qr)) },
        text = {
            Image(
                bitmap = qrBitmap.asImageBitmap(),
                contentDescription = stringResource(R.string.student_qr),
                modifier = Modifier
                    .size(250.dp)
                    .padding(top = 8.dp)
            )
        }
    )
}