package es.iesfernandoaguilar.ui.manager

import dagger.Lazy
import es.iesfernandoaguilar.models.objects.SessionData
import es.iesfernandoaguilar.ui.datastore.UserPreferences
import es.iesfernandoaguilar.utils.PasswordUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

class SessionManager @Inject constructor(
    private val userPreferences: UserPreferences,
    private val connectionManager: Lazy<ConnectionManager>,
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {

    // Sends a request to register a user with username and email
    fun registerUser(username: String, email: String) {
        connectionManager.get().sendRequestRegister(username, email)
    }

    // Sends a login request using email
    fun loginUser(email: String) {
        if (email.isBlank()) return
        connectionManager.get().sendRequestLogin(email)
    }

    // Creates a password hash using the salt and sends it
    fun manageSalt(salt: String) {
        val passwordHash = PasswordUtils.generateSHA512Hash(SessionData.passWord, salt)
        // Use safe call with default empty string to avoid null issues
        connectionManager.get().sendPassword(passwordHash.orEmpty())
    }

    // Saves user credentials asynchronously for auto-login
    fun saveAutoUserLogin() {
        val currentUser = SessionData.currentUser ?: return
        val password = SessionData.passWord
        coroutineScope.launch {
            userPreferences.saveUser(currentUser.email, password)
        }
    }

    // Clears saved user credentials asynchronously
    fun clearAutoUserLogin() {
        coroutineScope.launch {
            userPreferences.clearUser()
        }
    }

    // Returns whether auto-login is currently enabled
    fun isAutoUserLoginActive(): Boolean = SessionData.autoLoginActive

    // Attempts auto-login by retrieving stored email and password
    fun autoLogin() {
        coroutineScope.launch {
            // Use Kotlin's let to avoid multiple null checks
            val email = userPreferences.userEmailFlow.first().takeIf { it != null && it.isNotEmpty() } ?: return@launch
            val password = userPreferences.userPasswordFlow.first().takeIf { it != null && it.isNotEmpty() } ?: return@launch

            SessionData.passWord = password
            connectionManager.get().sendRequestLogin(email)
        }
    }
}
