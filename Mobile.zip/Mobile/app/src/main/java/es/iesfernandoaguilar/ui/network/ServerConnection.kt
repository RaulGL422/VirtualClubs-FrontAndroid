package es.iesfernandoaguilar.ui.network

import android.content.Context
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.models.network.Message
import es.iesfernandoaguilar.models.objects.ErrorHandler
import es.iesfernandoaguilar.ui.datastore.AppPreferences
import es.iesfernandoaguilar.ui.manager.ConnectionManager
import es.iesfernandoaguilar.ui.pages.SettingsDestination
import es.iesfernandoaguilar.utils.Serializator
import es.iesfernandoaguilar.utils.Serializator.serialize
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStreamReader
import java.net.Socket
import java.util.Properties
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException

@Singleton
class ServerConnection @Inject constructor(
    @ApplicationContext private val context: Context,
    private val connectionManager: ConnectionManager,
    private val appPreferences: AppPreferences
) {
    private var socket: Socket? = null
    private var reader: DataInputStream? = null
    private var writer: DataOutputStream? = null
    private var isRunning = false
    private var connectionDeferred: CompletableDeferred<Unit>? = null
    private var scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val sendMutex = Mutex()

    companion object {
        private const val TAG = "ServerConnection"
    }

    fun start() {
        if (isRunning) return

        // Reset the coroutine scope on each start
        scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        connectionDeferred = CompletableDeferred()

        scope.launch {
            try {
                val (serverIp, serverPort) = loadServerConfig()
                socket = Socket(serverIp, serverPort).apply {
                    reader = DataInputStream(getInputStream())
                    writer = DataOutputStream(getOutputStream())
                }
                isRunning = true
                Log.d(TAG, "Connected to server at $serverIp:$serverPort")
                connectionDeferred?.complete(Unit)

                listenUpdates()
            } catch (e: Exception) {
                Log.e(TAG, "Error connecting to server", e)
                ErrorHandler.showError(
                    R.string.cannot_connect_to_server,
                    errorName = R.string.reconfig_ip,
                    onRetryAction = {
                        connectionManager.navigateToPage(SettingsDestination.route)
                        ErrorHandler.clear()
                    }
                )
                stop()
            }
        }
    }

    // Listens for incoming messages on the socket.
    private fun listenUpdates() {
        try {
            while (isRunning) {
                val message = reader?.readUTF() ?: throw IOException("Input stream closed")
                Log.d(TAG, "Received message: $message")
                connectionManager.manageMessage(Serializator.deserialize(message))
            }
        } catch (e: IOException) {
            if (!isRunning) return
            Log.e(TAG, "Lost connection to server", e)
            showConnectionError()
            stop()
        }
    }

    // Sends a message to the server.
    fun sendMessage(message: Message) {
        scope.launch {
            // Wait for connection to be ready
            connectionDeferred?.await()

            try {
                sendMutex.withLock {
                    val serialized = serialize(message)
                    writer?.writeUTF(serialized)
                    writer?.flush()
                    Log.d(TAG, "Sent message: $serialized")
                }
            } catch (e: IOException) {
                if (!isRunning) return@launch
                Log.e(TAG, "Error sending message", e)
                showConnectionError()
                stop()
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error during sending", e)
            }
        }
    }

    /**
     * Loads server IP and port from app preferences and properties file.
     * Suspends until values are available.
     */
    private suspend fun loadServerConfig(): Pair<String, Int> = withContext(Dispatchers.IO) {
        val properties = Properties().apply {
            load(InputStreamReader(context.assets.open("server-config.properties")))
        }
        val serverIp = appPreferences.serverIpFlow.first()
        val serverPort = properties.getProperty("server.port")?.toIntOrNull() ?: 0
        return@withContext serverIp to serverPort
    }

    fun stop() {
        isRunning = false
        connectionDeferred?.cancel(CancellationException("Connection stopped"))
        scope.cancel()
        close()
    }

    private fun close() {
        try {
            reader?.close()
            writer?.close()
            socket?.close()
            Log.d(TAG, "Connection closed")
        } catch (e: IOException) {
            Log.w(TAG, "Error closing connection", e)
        }
    }

    /**
     * Requests a club photo from the server on the specified port.
     * Times out after 10 seconds.
     */
    suspend fun requestClubPhoto(port: Int): ByteArray = withTimeout(10_000) {
        val serverIp = appPreferences.serverIpFlow.first()

        Socket(serverIp, port).use { socket ->
            val reader = DataInputStream(socket.getInputStream())
            val length = reader.readInt()
            ByteArray(length).also { reader.readFully(it) }
        }
    }

    // Shows a connection error dialog with retry option.
    private fun showConnectionError() {
        ErrorHandler.showError(
            R.string.lose_connection_with_server,
            errorName = R.string.reconnect,
            onRetryAction = {
                connectionManager.reconnect()
                ErrorHandler.clear()
            }
        )
    }
}
