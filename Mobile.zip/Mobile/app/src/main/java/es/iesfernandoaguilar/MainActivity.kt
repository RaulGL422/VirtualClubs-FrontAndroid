package es.iesfernandoaguilar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import dagger.hilt.android.AndroidEntryPoint
import es.iesfernandoaguilar.ui.TFGMainApp
import es.iesfernandoaguilar.ui.datastore.AppPreferences
import es.iesfernandoaguilar.ui.theme.TFGMobileTheme
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    @Inject
    lateinit var appPreferences: AppPreferences

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TFGMobileTheme(
                preferences = appPreferences
            ) {
                val windowSize = calculateWindowSizeClass(this)
                TFGMainApp(windowSize.widthSizeClass)
            }
        }
    }
}