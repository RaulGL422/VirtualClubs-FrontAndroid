package es.iesfernandoaguilar.models.objects

import dagger.Lazy
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import es.iesfernandoaguilar.ui.datastore.UserPreferences
import es.iesfernandoaguilar.ui.manager.ClassManager
import es.iesfernandoaguilar.ui.manager.ClubManager
import es.iesfernandoaguilar.ui.manager.ConnectionManager
import es.iesfernandoaguilar.ui.manager.RequestManager
import es.iesfernandoaguilar.ui.manager.SessionManager
import es.iesfernandoaguilar.ui.manager.UserManager
import es.iesfernandoaguilar.ui.network.ServerConnection
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ManagersModule {

    @Singleton
    @Provides
    fun provideConnectionManager(
        sessionManager: Lazy<SessionManager>,
        clubManager: Lazy<ClubManager>,
        requestManager: Lazy<RequestManager>,
        userManager: Lazy<UserManager>,
        classManager: Lazy<ClassManager>,
        serverConnection: Lazy<ServerConnection>
    ): ConnectionManager = ConnectionManager(sessionManager, clubManager, requestManager, classManager, userManager, serverConnection)

    @Singleton
    @Provides
    fun provideSessionManager(
        userPreferences: UserPreferences,
        connectionManager: Lazy<ConnectionManager>
    ): SessionManager = SessionManager(userPreferences, connectionManager)

    @Singleton
    @Provides
    fun provideUserManager(
        connectionManager: Lazy<ConnectionManager>
    ): UserManager = UserManager(connectionManager)

    @Singleton
    @Provides
    fun provideRequestManager(
        connectionManager: Lazy<ConnectionManager>
    ): RequestManager = RequestManager(connectionManager)

    @Singleton
    @Provides
    fun provideClubManager(
        connectionManager: Lazy<ConnectionManager>
    ): ClubManager = ClubManager(connectionManager)

    @Singleton
    @Provides
    fun provideClassManager(
        connectionManager: Lazy<ConnectionManager>
    ): ClassManager = ClassManager(connectionManager)
}