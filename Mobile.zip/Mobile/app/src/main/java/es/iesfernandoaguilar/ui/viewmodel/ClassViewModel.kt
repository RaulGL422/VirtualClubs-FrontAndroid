package es.iesfernandoaguilar.ui.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import es.iesfernandoaguilar.models.ClassComplete
import es.iesfernandoaguilar.models.Student
import es.iesfernandoaguilar.models.ViewModelControl
import es.iesfernandoaguilar.models.objects.SessionData
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.manager.ClassManager
import es.iesfernandoaguilar.ui.manager.RequestManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDateTime
import javax.inject.Inject

@HiltViewModel
class ClassViewModel @Inject constructor(
    private val classManager: ClassManager,
    private val requestManager: RequestManager
) : ViewModel(), ViewModelControl {
    var classUiState: ClassUiState by mutableStateOf(ClassUiState.Loading)
        private set

    var studentsUiState: StudentsUiState by mutableStateOf(StudentsUiState.Loading)
        private set

    var assistanceUiState: AssistanceUiState by mutableStateOf(AssistanceUiState.Loading)
        private set

    // Internal state holder
    private val _state = MutableStateFlow(ClassState())
    val state: StateFlow<ClassState> = _state.asStateFlow()

    init {
        ViewModelActive.setActive(this)
        SessionData.classSelected?.let { classId ->
            classManager.requestCompleteClassInfo(classId)
        } ?: run {
            Log.e("ClassViewModel", "No class selected in session!")
        }
    }

    // Loads complete class info and updates state
    fun loadCompleteClassInfo(classComplete: ClassComplete) {
        _state.value = _state.value.copy(clazz = classComplete)
        if (classManager.isClassFinished(classComplete)) {
            classComplete.canManage = false
        }
        classUiState = ClassUiState.Success

        if (classComplete.canManage) {
            SessionData.classSelected?.let { classId ->
                requestManager.requestStudentsCanJoinClass(classId)
            }
        }
    }

    // Loads list of students that can be invited to the class
    fun loadStudentsToRequest(students: List<Student>) {
        val noCapacity = students.size == 1 && students.first().id == -1L

        _state.value = _state.value.copy(
            students = students,
            noCapacity = noCapacity,
            selectedStudent = null
        )

        studentsUiState = StudentsUiState.Success
    }

    // Requests assistance info for a specific student
    fun requestAssistanceToStudent(userNameStudent: String) {
        assistanceUiState = AssistanceUiState.Loading

        _state.value.clazz?.let { clazz ->
            classManager.requestAssistance(clazz, userNameStudent)
        } ?: Log.e("ClassViewModel", "Class info is null when requesting assistance")
    }

    // Updates assistance list in state
    fun updateAssistance(assistanceList: List<LocalDateTime>) {
        _state.value = _state.value.copy(assistances = assistanceList)
        assistanceUiState = AssistanceUiState.Success
    }

    fun updateSelectedStudent(student: Student) {
        _state.value = _state.value.copy(selectedStudent = student)
    }

    // Unlinks a student from the class
    fun unLinkStudent(student: Student) {
        _state.value.clazz?.let { clazz ->
            classManager.unLinkStudent(clazz, student)
        } ?: Log.e("ClassViewModel", "Class info is null when unlinking student")
    }

    // Sends enrollment request for a student
    fun sendRequest() {
        _state.value.clazz?.let { clazz ->
            requestManager.sendEnrollmentRequest(clazz, _state.value.selectedStudent!!)
        } ?: Log.e("ClassViewModel", "Class info is null when sending request")
    }

    // Adds new assistance record based on scanned QR code
    fun addNewAssistance(scannedId: String, scannedDate: LocalDateTime) {
        Log.i("ClassViewModel", "Registering assistance for user: $scannedId")

        _state.value.clazz?.let { clazz ->
            classManager.sendAssistance(clazz.idClass, scannedId, scannedDate)
        } ?: Log.e("ClassViewModel", "Class info is null when adding new assistance")
    }
}

// Data holder for UI state
data class ClassState(
    val clazz: ClassComplete? = null,
    val students: List<Student> = emptyList(),
    val noCapacity: Boolean = true,
    val assistances: List<LocalDateTime> = emptyList(),
    val selectedStudent: Student? = null
)

// UI state sealed interfaces for better state management
sealed interface ClassUiState {
    object Success : ClassUiState
    object Loading : ClassUiState
}

sealed interface StudentsUiState {
    object Success : StudentsUiState
    object Loading : StudentsUiState
}

sealed interface AssistanceUiState {
    object Success : AssistanceUiState
    object Loading : AssistanceUiState
}
