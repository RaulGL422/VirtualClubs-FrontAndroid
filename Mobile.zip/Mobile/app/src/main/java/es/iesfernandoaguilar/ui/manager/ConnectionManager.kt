package es.iesfernandoaguilar.ui.manager

import android.util.Log
import dagger.Lazy
import es.iesfernandoaguilar.models.ClubComplete
import es.iesfernandoaguilar.models.User
import es.iesfernandoaguilar.models.enums.TypeMessage
import es.iesfernandoaguilar.models.network.Message
import es.iesfernandoaguilar.models.objects.ErrorHandler
import es.iesfernandoaguilar.models.objects.NotifyHandler
import es.iesfernandoaguilar.models.objects.SessionData
import es.iesfernandoaguilar.ui.network.ServerConnection
import es.iesfernandoaguilar.ui.pages.ActiveUserDestination
import es.iesfernandoaguilar.ui.pages.HomeDestination
import es.iesfernandoaguilar.ui.pages.UserInformationDestination
import es.iesfernandoaguilar.utils.ClassUtils
import es.iesfernandoaguilar.utils.UserUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject

class ConnectionManager @Inject constructor(
    private val sessionManager: Lazy<SessionManager>,
    private val clubManager: Lazy<ClubManager>,
    private val requestManager: Lazy<RequestManager>,
    private val classManager: Lazy<ClassManager>,
    private val userManager: Lazy<UserManager>,
    private val connection: Lazy<ServerConnection>
) {
    private val _navigationCommands = MutableSharedFlow<String>()
    val navigationCommands: SharedFlow<String> = _navigationCommands

    fun navigateToPage(route: String) {
        CoroutineScope(Dispatchers.IO).launch {
            _navigationCommands.emit(route)
        }
    }

    fun manageMessage(message: Message) {
        try {
            when (val type = message.type) {
                // Login
                TypeMessage.SALT -> manageSalt(message.args[0])
                TypeMessage.MUST_ACTIVE_USER -> navigateToPage(ActiveUserDestination.route)
                TypeMessage.MUST_COMPLETE_USER -> mustCompleteInfo(message.args)
                TypeMessage.LOGIN_SUCCESS -> loginSuccess(message.args)

                // Club
                TypeMessage.CLUB_RESUME_LIST_INFO -> clubResumeListInfo(message.args[0], message.args[1])
                TypeMessage.CLUB_INFO -> manageClubInfo(
                    name = message.args[0],
                    cif = message.args[1],
                    description = message.args[2],
                    address = message.args[3],
                    city = message.args[4],
                    postalCode = message.args[5],
                    canManage = message.args[6] == "1",
                    userList = message.args[7]
                )

                // Class
                TypeMessage.CLASS_COMPLETE_INFO -> completeClassInfo(message.args[0], message.args[1])
                TypeMessage.CLASS_CLIENT_LIST -> classList(message.args[0])
                TypeMessage.PUBLIC_CLASS_LIST -> publicClassList(message.args[0])
                TypeMessage.USERS_CAN_JOIN_CLASS_LIST -> usersCanJoinClassList(message.args[0])
                TypeMessage.ASSISTANCE_LIST -> updateAssistance(message.args[0])

                // Requests
                TypeMessage.REQUESTS_LIST_INFO -> requestsListInfo(message.args[0])
                TypeMessage.ENROLLMENT_REQUEST_LIST -> enrollmentRequestList(message.args[0])

                // Notifications
                TypeMessage.EMAIL_CODE_SENT,
                TypeMessage.JOINED_PUBLIC_CLASS,
                TypeMessage.ENROLLMENT_REQUEST_ACCEPTED,
                TypeMessage.ENROLLMENT_REQUEST_DECLINED,
                TypeMessage.REQUEST_ACCEPTED,
                TypeMessage.REQUEST_DECLINED,
                TypeMessage.REMOVED_INSCRIPTION,
                TypeMessage.REQUEST_SENT,
                TypeMessage.ENROLLMENT_REQUEST_SENT,
                TypeMessage.ASSISTANCE_ADDED,
                TypeMessage.REMOVED_ENROLLMENT,
                TypeMessage.CLASS_CREATED,
                TypeMessage.CLASS_UPDATED,
                TypeMessage.CLASS_DELETED,
                TypeMessage.CREATE_EMPLOYEE_ROLE_SUCCESS,
                TypeMessage.DELETE_EMPLOYEE_ROLE_SUCCESS,
                TypeMessage.UPDATE_EMPLOYEE_ROLE_SUCCESS,
                TypeMessage.CREATE_EMPLOYEE_SUCCESS,
                TypeMessage.DELETE_EMPLOYEE_SUCCESS,
                TypeMessage.UPDATE_EMPLOYEE_SUCCESS,
                TypeMessage.CREATED_ROOM,
                TypeMessage.DELETED_ROOM,
                TypeMessage.UPDATED_ROOM,
                    -> NotifyHandler.showNotify(type)

                // Errors
                TypeMessage.EMAIL_NOT_VALID,
                TypeMessage.REGISTER,
                TypeMessage.LOGIN,
                TypeMessage.EMAIL_YET_REGISTERED,
                TypeMessage.USER_NOT_VALID,
                TypeMessage.RECEIVE_PASSWORD_ERROR,
                TypeMessage.INCORRECT_CREDENTIALS,
                TypeMessage.COMPLETE_REGISTER_ERROR,
                TypeMessage.USER_NOT_FOUND,
                TypeMessage.EMAIL_NOT_FOUND,
                TypeMessage.INSCRIPTION_NOT_FOUND,
                TypeMessage.CLUB_NOT_FOUND,
                TypeMessage.EMPLOYEE_NOT_FOUND,
                TypeMessage.REQUEST_NOT_FOUND,
                TypeMessage.ENROLLMENT_REQUEST_NOT_FOUND,
                TypeMessage.NOT_EMPLOYEE_ROLE_FOUNDED,
                TypeMessage.NO_CLUB_PERMISSION,
                TypeMessage.CLASS_ENROLLMENT_NOT_FOUND,
                TypeMessage.CLASS_NOT_FOUND,
                TypeMessage.ROOM_NOT_FOUNDED,
                TypeMessage.EMAIL_CODE_ERROR,
                TypeMessage.REQUEST_ACTIVE_CODE_ERROR,
                TypeMessage.VERIFY_ACTIVE_CODE_ERROR,
                TypeMessage.USER_CODE_IS_WRONG,
                TypeMessage.UPDATE_FAILED,
                TypeMessage.INVALID_NUMBER_PHONE,
                TypeMessage.INVALID_DATE,
                TypeMessage.REQUEST_ENROLLMENT_REQUEST_FAILED,
                TypeMessage.REQUEST_ENROLLMENT_CLASSES_FAILED,
                TypeMessage.REQUEST_PUBLIC_CLASSES_FAILED,
                TypeMessage.USER_CANT_ENROLL_BY_AGE,
                TypeMessage.CLASS_CAPACITY_IS_FULL,
                TypeMessage.JOIN_PUBLIC_CLASS_FAILED,
                TypeMessage.CANT_REMOVE_ENROLLMENT_REQUEST,
                TypeMessage.ACCEPT_ENROLLMENT_REQUEST_FAILED,
                TypeMessage.DECLINE_ENROLLMENT_REQUEST_FAILED,
                TypeMessage.RESOLVE_REQUEST_FAILED,
                TypeMessage.REQUEST_USER_REQUEST_FAILED,
                TypeMessage.CANT_CREATE_INSCRIPTION,
                TypeMessage.CANT_DELETE_INSCRIPTION_REQUEST,
                TypeMessage.INSCRIPTION_YET_EXIST,
                TypeMessage.REQUEST_CLUB_USER_RESUME_FAILED,
                TypeMessage.REQUEST_CLUB_DATA_FAILED,
                TypeMessage.CANT_CREATE_REQUEST,
                TypeMessage.CANT_DELETE_INSCRIPTION,
                TypeMessage.DELETE_INSCRIPTION_FAILED,
                TypeMessage.CANT_INVITE_OWNER,
                TypeMessage.CREATE_ENROLLMENT_REQUEST_FAILED,
                TypeMessage.CANT_CREATE_ENROLLMENT_REQUEST,
                TypeMessage.CLASS_ENROLLMENT_YET_EXIST,
                TypeMessage.CANT_INVITE_INSTRUCTOR,
                TypeMessage.REQUEST_CLASS_INFO_FAILED,
                TypeMessage.REMOVE_CLASS_ENROLLMENT_FAILED,
                TypeMessage.CANT_REMOVE_ENROLLMENT,
                TypeMessage.REQUEST_STUDENTS_CAN_JOIN_FAILED,
                TypeMessage.ADD_NEW_ASSISTANCE_FAILED,
                TypeMessage.CANT_CREATE_ASSISTANCE,
                TypeMessage.REQUEST_ASSISTANCE_FAILED,
                TypeMessage.REQUEST_ROOMS_FAILED,
                TypeMessage.REQUEST_STUDENT_FAILED,
                TypeMessage.REQUEST_EMPLOYEES_FAILED,
                TypeMessage.REQUEST_EMPLOYEE_ROLES_FAILED,
                TypeMessage.REQUEST_CLASSES_FAILED,
                TypeMessage.CREATE_NEW_ROOM_FAILED,
                TypeMessage.UPDATE_ROOM_FAILED,
                TypeMessage.REMOVE_ROOM_FAILED,
                TypeMessage.CANT_CREATE_ROOM_FAILED,
                TypeMessage.CANT_UPDATE_ROOM_FAILED,
                TypeMessage.CANT_REMOVE_ROOM_FAILED,
                TypeMessage.NO_CAPACITY_ROOM,
                TypeMessage.CLUB_CREATED_FAILED,
                TypeMessage.CANT_CREATE_CLUB,
                TypeMessage.INVALID_CIF,
                TypeMessage.PHOTO_CANT_BE_UPLOADED,
                TypeMessage.CANT_CREATE_EMPLOYEE_ROLE,
                TypeMessage.CANT_DELETE_EMPLOYEE_ROLE,
                TypeMessage.CREATE_EMPLOYEE_ROLE_FAILED,
                TypeMessage.UPDATE_EMPLOYEE_ROLE_FAILED,
                TypeMessage.DELETE_EMPLOYEE_ROLE_FAILED,
                TypeMessage.CANT_DELETE_EMPLOYEE,
                TypeMessage.CANT_CREATE_EMPLOYEE,
                TypeMessage.CANT_UPDATE_EMPLOYEE,
                TypeMessage.CANT_CREATE_REQUESTS,
                TypeMessage.CANT_UPDATE_EMPLOYEE_ROLE,
                TypeMessage.CREATE_NEW_EMPLOYEE_ROLE_FAILED,
                TypeMessage.DELETE_EMPLOYEE_FAILED,
                TypeMessage.UPDATE_EMPLOYEE_FAILED,
                TypeMessage.CREATE_CLASS_FAILED,
                TypeMessage.CANT_CREATE_CLASS_FAILED,
                TypeMessage.REPEAT_UNTIL_DATE_INVALID,
                TypeMessage.CONCLIC_EMPLOYEE_SCHEDULE,
                TypeMessage.UNIQUE_DATE_INVALID,
                TypeMessage.EMPLOYEE_NO_PERMISSION_INSTRUCTOR,
                TypeMessage.NO_STUDENTS_CAPACITY,
                TypeMessage.CONCLIC_ROOM_SCHEDULE,
                TypeMessage.AGE_RANGE_INVALID,
                TypeMessage.NAME_ALREADY_EXIST_IN_CLASS,
                TypeMessage.UPDATE_CLASS_FAILED,
                TypeMessage.CANT_UPDATE_CLASS,
                TypeMessage.DELETE_CLASS_FAILED,
                TypeMessage.CANT_REMOVE_CLASS,
                    -> ErrorHandler.showError(type)

                else -> Log.e("Unknown Message", message.toString())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // ------------------------------
    // Private functions
    // ------------------------------

    private fun sendMessage(type: TypeMessage, args: List<String>) {
        connection.get().start()
        connection.get().sendMessage(Message(type, args))
    }

    private fun manageSalt(salt: String) {
        sessionManager.get().manageSalt(salt)
    }

    private fun mustCompleteInfo(args: List<String>) {
        SessionData.currentUser = User(args[0], args[1])
        if (sessionManager.get().isAutoUserLoginActive()) sessionManager.get().saveAutoUserLogin()
        navigateToPage(UserInformationDestination.route)
    }

    private fun loginSuccess(args: List<String>) {
        SessionData.currentUser = User(args[0], args[1])
        if (sessionManager.get().isAutoUserLoginActive()) sessionManager.get().saveAutoUserLogin()
        navigateToPage(HomeDestination.route)
    }

    private fun manageClubInfo(
        name: String,
        cif: String,
        description: String,
        address: String,
        city: String,
        postalCode: String,
        canManage: Boolean,
        userList: String,
    ) {
        clubManager.get().manageClubInfo(
            ClubComplete(
                SessionData.clubSelected!!.id,
                name,
                SessionData.clubSelected!!.photo != null,
                SessionData.clubSelected!!.photo,
                cif,
                description,
                address,
                city,
                postalCode,
                canManage,
                UserUtils.deserializeUserList(userList)
            )
        )
    }

    private fun completeClassInfo(classInfo: String, students: String) {
        classManager.get().completeClassInfo(ClassUtils.deserializeClassComplete(classInfo, students))
    }

    private fun classList(classListInfo: String) {
        classManager.get().classList(classListInfo)
    }

    private fun enrollmentRequestList(enrollmentRequestListInfo: String) {
        requestManager.get().enrollmentRequestList(enrollmentRequestListInfo)
    }

    private fun publicClassList(publicClassListInfo: String) {
        classManager.get().publicClassList(publicClassListInfo)
    }

    private fun usersCanJoinClassList(users: String) {
        userManager.get().usersCanJoinIntoClass(UserUtils.deserializeUserList(users))
    }

    private fun updateAssistance(assistanceInfo: String) {
        classManager.get().updateAssistance(assistanceInfo)
    }

    private fun clubResumeListInfo(personalClub: String, clubList: String) {
        CoroutineScope(Dispatchers.IO).launch {
            clubManager.get().manageClubsResumeInfo(personalClub, clubList)
        }
    }

    private fun requestsListInfo(requests: String) {
        CoroutineScope(Dispatchers.IO).launch {
            requestManager.get().getRequestList(requests)
        }
    }

    // ------------------------------
    // Public Message Senders
    // ------------------------------

    fun sendRequestRegister(user: String, email: String) =
        sendMessage(TypeMessage.USER_REGISTER, listOf(user, email))

    fun sendRequestLogin(email: String) =
        sendMessage(TypeMessage.USER_LOGIN, listOf(email))

    fun sendPassword(passWd: String) =
        sendMessage(TypeMessage.PASSWD, listOf(passWd))

    fun sendActiveUserCode(code: String) =
        sendMessage(TypeMessage.USER_ACTIVE_CODE, listOf(code))

    fun requestActiveCode() =
        sendMessage(TypeMessage.USER_REQUEST_ACTIVE_CODE, listOf())

    fun sendUpdateUserInfo(
        name: String,
        surname: String,
        phoneNumber: String,
        dateOfBirth: LocalDate,
        gender: String,
        address: String,
        city: String,
        postalCode: String
    ) = sendMessage(TypeMessage.USER_COMPLETE_INFO, listOf(
            name, surname, phoneNumber,
            dateOfBirth.format(DateTimeFormatter.ISO_LOCAL_DATE),
            gender, address, city, postalCode
        )
    )

    fun requestUserClubResume() =
        sendMessage(TypeMessage.REQUEST_USER_CLUBS_RESUME, listOf())

    suspend fun requestPhoto(port: Int): ByteArray =
        connection.get().requestClubPhoto(port)

    fun requestCompleteClubInfo(clubId: Long) =
        sendMessage(TypeMessage.REQUEST_CLUB_DATA, listOf(clubId.toString()))

    fun sendNewInscriptionRequest(idClub: Long, userName: String) =
        sendMessage(TypeMessage.SEND_NEW_REQUEST, listOf(idClub.toString(), userName))

    fun sendRequestsToInscriptionRequest() =
        sendMessage(TypeMessage.REQUEST_USER_REQUESTS, listOf())

    fun sendAcceptRequest(idRequest: Long) =
        sendMessage(TypeMessage.ACCEPT_REQUEST, listOf(idRequest.toString()))

    fun sendDeclineRequest(idRequest: Long) =
        sendMessage(TypeMessage.DECLINE_REQUEST, listOf(idRequest.toString()))

    fun sendEnrollmentRequest(idUser: Long, idClass: Long) =
        sendMessage(TypeMessage.SEND_ENROLLMENT_REQUEST, listOf(idClass.toString(), idUser.toString()))

    fun sendAcceptEnrollmentRequest(idRequest: Long) =
        sendMessage(TypeMessage.ACCEPT_ENROLLMENT_REQUEST, listOf(idRequest.toString()))

    fun sendDeclineEnrollmentRequest(idRequest: Long) =
        sendMessage(TypeMessage.DECLINE_ENROLLMENT_REQUEST, listOf(idRequest.toString()))

    fun sendRequestEnrollmentRequests() =
        sendMessage(TypeMessage.REQUEST_ENROLLMENT_REQUEST, listOf())

    fun sendRequestEnrollmentClasses() =
        sendMessage(TypeMessage.REQUEST_ENROLLMENT_CLASSES, listOf())

    fun requestPublicClasses() =
        sendMessage(TypeMessage.REQUEST_PUBLIC_CLASSES, listOf())

    fun sendJoinPublicClass(idClass: Long) =
        sendMessage(TypeMessage.JOIN_PUBLIC_CLASS, listOf(idClass.toString()))

    fun sendRequestClassInfo(idClass: Long) =
        sendMessage(TypeMessage.REQUEST_CLASS_INFO, listOf(idClass.toString()))

    fun sendRequestStudentsCanJoinClass(idClass: Long) =
        sendMessage(TypeMessage.REQUEST_STUDENTS_CAN_JOIN_CLASS, listOf(idClass.toString()))

    fun sendAssistance(idClass: Long, studentUserName: String, dateTime: LocalDateTime) =
        sendMessage(TypeMessage.NEW_ASSISTANCE, listOf(idClass.toString(), studentUserName, dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)))

    fun unLinkStudent(studentId: Long, clubId: Long) =
        sendMessage(TypeMessage.UNLINK_STUDENT, listOf(clubId.toString(), studentId.toString()))

    fun unLinkClassStudent(classId: Long, userId: Long) =
        sendMessage(TypeMessage.REMOVE_CLASS_ENROLLMENT, listOf(classId.toString(), userId.toString()))

    fun requestAssistance(classId: Long, userName: String) =
        sendMessage(TypeMessage.REQUEST_ASSISTANCES, listOf(classId.toString(), userName))

    fun logout() = connection.get().stop()

    fun reconnect() = sessionManager.get().loginUser(SessionData.currentUser?.email ?: "")
}