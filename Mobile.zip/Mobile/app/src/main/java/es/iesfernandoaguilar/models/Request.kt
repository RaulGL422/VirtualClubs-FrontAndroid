package es.iesfernandoaguilar.models

import java.time.LocalDateTime

data class Request(
    val id: Long,
    val club: Club,
    val date: LocalDateTime
)