package es.iesfernandoaguilar.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.models.ViewModelControl
import es.iesfernandoaguilar.models.objects.ErrorHandler
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.manager.UserManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeParseException
import javax.inject.Inject

@HiltViewModel
class UserInformationViewModel @Inject constructor(
    private val userManager: UserManager
) : ViewModelControl, ViewModel() {

    private val _formState = MutableStateFlow(UserFormState())
    val formState: StateFlow<UserFormState> = _formState.asStateFlow()

    // Update functions for each field
    fun onNameChanged(value: String) {
        _formState.value = _formState.value.copy(name = value)
    }

    fun onSurnameChanged(value: String) {
        _formState.value = _formState.value.copy(surname = value)
    }

    fun onPhoneNumberChanged(value: String) {
        _formState.value = _formState.value.copy(phoneNumber = value)
    }

    fun onDateOfBirthChanged(value: String) {
        _formState.value = _formState.value.copy(dateOfBirth = value)
    }

    fun onGenderChanged(value: String) {
        _formState.value = _formState.value.copy(gender = value)
    }

    fun onAddressChanged(value: String) {
        _formState.value = _formState.value.copy(address = value)
    }

    fun onCityChanged(value: String) {
        _formState.value = _formState.value.copy(city = value)
    }

    fun onPostalCodeChanged(value: String) {
        _formState.value = _formState.value.copy(postalCode = value)
    }

    fun sendInfo() {
        val state = _formState.value

        val requiredFields = listOf(
            state.name to R.string.name_cant_be_empty,
            state.surname to R.string.surname_cant_be_empty,
            state.phoneNumber to R.string.phonenumber_cant_be_empty,
            state.dateOfBirth to R.string.dateofbirth_cant_be_empty,
            state.gender to R.string.gender_cant_be_empty,
            state.address to R.string.address_cant_be_empty,
            state.city to R.string.city_cant_be_empty,
            state.postalCode to R.string.postalcode_cant_be_empty
        )

        for ((field, errorResId) in requiredFields) {
            if (field.isBlank()) {
                ErrorHandler.showError(errorResId)
                return
            }
        }

        val dateOfBirthParsed = try {
            LocalDate.parse(state.dateOfBirth)
        } catch (e: DateTimeParseException) {
            ErrorHandler.showError(R.string.dateofbirth_format_invalid)
            return
        }

        Log.i("UserInformation", "Sending user information to update")

        viewModelScope.launch {
            userManager.sendUserInfo(
                name = state.name,
                surname = state.surname,
                phoneNumber = state.phoneNumber,
                dateOfBirth = dateOfBirthParsed,
                gender = state.gender,
                address = state.address,
                city = state.city,
                postalCode = state.postalCode
            )
        }
    }

    init {
        ViewModelActive.setActive(this)
    }
}


data class UserFormState(
    val name: String = "",
    val surname: String = "",
    val phoneNumber: String = "",
    val dateOfBirth: String = "",
    val gender: String = "",
    val address: String = "",
    val city: String = "",
    val postalCode: String = ""
)