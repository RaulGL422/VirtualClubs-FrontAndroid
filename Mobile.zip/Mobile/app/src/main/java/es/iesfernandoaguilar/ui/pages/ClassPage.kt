package es.iesfernandoaguilar.ui.pages

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.models.objects.ErrorHandler
import es.iesfernandoaguilar.models.objects.SessionData
import es.iesfernandoaguilar.ui.ScreenType
import es.iesfernandoaguilar.ui.components.AppBar
import es.iesfernandoaguilar.ui.navigation.Destination
import es.iesfernandoaguilar.ui.viewmodel.AssistanceUiState
import es.iesfernandoaguilar.ui.viewmodel.ClassUiState
import es.iesfernandoaguilar.ui.viewmodel.ClassViewModel
import es.iesfernandoaguilar.ui.viewmodel.StudentsUiState
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle

object ClassDestination : Destination {
    override val route = "class"
    override val titleRes = -1
}

@SuppressLint("LocalContextConfigurationRead")
@Composable
fun ClassPage(
    viewModel: ClassViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit,
    onSettingsPressed: () -> Unit,
    screenType: ScreenType
) {
    val context = LocalContext.current
    val classUiState = viewModel.classUiState
    val assistanceUiState = viewModel.assistanceUiState
    val studentsUiState = viewModel.studentsUiState
    val classState by viewModel.state.collectAsState()

    // States for QR scanning flow and dialogs
    var scannedId by remember { mutableStateOf<String?>(null) }
    var scannedDate by remember { mutableStateOf<LocalDateTime?>(null) }
    var showCamera by remember { mutableStateOf(false) }
    var showAssistanceDialog by remember { mutableStateOf(false) }

    // Width adjustment depending on screen size
    val contentWidth = when (screenType) {
        ScreenType.Medium -> 0.7f
        ScreenType.Small -> 0.8f
    }

    Scaffold(
        topBar = {
            AppBar(
                canGoBack = true,
                onNavigateBack = onNavigateBack,
                titleResId = R.string.class_page,
                titleString = classState.clazz?.name,
                actions = {
                    IconButton(onClick = onSettingsPressed) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        floatingActionButton = {
            // Show camera FAB only if class loaded successfully and user can manage it
            if (classUiState is ClassUiState.Success && classState.clazz?.canManage == true) {
                FloatingActionButton(
                    onClick = { showCamera = true },
                    containerColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(
                        Icons.Default.CameraAlt,
                        contentDescription = stringResource(R.string.scan_qr)
                    )
                }
            }
        }
    ) { paddingValues ->

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (classUiState) {
                is ClassUiState.Loading -> {
                    // Show loading spinner while class info is loading
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }

                is ClassUiState.Success -> {
                    val clazz = classState.clazz!!

                    val locale = context.resources.configuration.locales[0]
                    val dateFormatter = remember { DateTimeFormatter.ofPattern("dd MMMM yyyy", locale) }

                    // Build schedule text depending on uniqueDate flag
                    val scheduleText = if (clazz.uniqueDate) {
                        "${clazz.uniqueDateDay!!.format(dateFormatter)} | ${clazz.startTime} - ${clazz.endTime}"
                    } else {
                        val daysOfWeek = clazz.weekDays?.joinToString(", ") {
                            it.getDisplayName(TextStyle.FULL, locale)
                        }
                        "${clazz.startTime} - ${clazz.endTime} | $daysOfWeek"
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth(contentWidth)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                        ) {
                            // Title and description
                            Text(
                                text = clazz.name,
                                style = MaterialTheme.typography.headlineLarge
                            )
                            Text(
                                text = clazz.description,
                                style = MaterialTheme.typography.bodyLarge
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            // General info header
                            Text(
                                stringResource(R.string.general_information),
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Class details fields
                            Text(stringResource(R.string.club_field, clazz.clubName))
                            Text(stringResource(R.string.room_field, clazz.roomName))
                            Text(stringResource(R.string.instructor_field, clazz.instructorName))
                            Text(stringResource(R.string.schedule_field, scheduleText))
                            Text(stringResource(R.string.type_field, stringResource(if (clazz.public) R.string.publicc else R.string.privatee)))

                            Spacer(modifier = Modifier.height(24.dp))

                            // Assistance section
                            Text(
                                stringResource(R.string.assistance),
                                style = MaterialTheme.typography.titleMedium
                            )
                            TextButton(
                                onClick = {
                                    viewModel.requestAssistanceToStudent(SessionData.currentUser!!.userName)
                                    showAssistanceDialog = true
                                }
                            ) {
                                Text(stringResource(R.string.show_assistance))
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Manager-only sections: students and invitations
                            if (clazz.canManage) {
                                when (studentsUiState) {
                                    is StudentsUiState.Loading -> {
                                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            CircularProgressIndicator()
                                        }
                                    }
                                    is StudentsUiState.Success -> {
                                        Text(stringResource(R.string.students), style = MaterialTheme.typography.titleMedium)

                                        // List students with unlink and show assistance buttons
                                        clazz.students.forEach { student ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("${student.surName}, ${student.name}")

                                                Row {
                                                    Button(onClick = { viewModel.unLinkStudent(student) }) {
                                                        Text(stringResource(R.string.unlink))
                                                    }
                                                    Button(onClick = {
                                                        viewModel.requestAssistanceToStudent(student.userName)
                                                        showAssistanceDialog = true
                                                    }) {
                                                        Text(stringResource(R.string.show_assistance))
                                                    }
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(24.dp))

                                        // Invite students section
                                        Text(stringResource(R.string.invite_students), style = MaterialTheme.typography.titleMedium)

                                        var expanded by remember { mutableStateOf(false) }

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box {
                                                Button(onClick = { expanded = true }, enabled = !classState.noCapacity) {
                                                    Text(
                                                        text = classState.selectedStudent?.userName
                                                            ?: stringResource(if (classState.noCapacity) R.string.no_capacity else R.string.select_student)
                                                    )
                                                }
                                                DropdownMenu(
                                                    expanded = expanded,
                                                    onDismissRequest = { expanded = false }
                                                ) {
                                                    classState.students.forEach { student ->
                                                        DropdownMenuItem(
                                                            text = { Text(student.userName) },
                                                            onClick = {
                                                                viewModel.updateSelectedStudent(student)
                                                                expanded = false
                                                            }
                                                        )
                                                    }
                                                }
                                            }

                                            Button(
                                                onClick = {
                                                    viewModel.sendRequest()
                                                },
                                                enabled = classState.selectedStudent != null
                                            ) {
                                                Text(stringResource(R.string.invite))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // QR Scanner flow
            if (showCamera) {
                if (scannedId == null) {
                    QRScannerWithPermission(
                        onQrScanned = { studentId, dateTime ->
                            scannedId = studentId
                            scannedDate = dateTime
                        },
                        onError = { msg -> ErrorHandler.showError(msg) }
                    )
                } else {
                    scannedDate?.let { date ->
                        viewModel.addNewAssistance(scannedId!!, date)
                        // Reset scanned data and close camera
                        scannedId = null
                        scannedDate = null
                        showCamera = false
                    }
                }
            }

            // Assistance dialog
            if (showAssistanceDialog) {
                AssistanceListDialog(
                    onDismiss = { showAssistanceDialog = false },
                    assistanceList = classState.assistances,
                    assistanceUiState = assistanceUiState
                )
            }
        }
    }
}

@OptIn(ExperimentalGetImage::class)
@Composable
fun QRScannerScreen(
    onQrScanned: (String, LocalDateTime) -> Unit,
    onError: (Int) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val cameraProvider = cameraProviderFuture.get()

            val barcodeScanner = BarcodeScanning.getClient()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            val imageAnalyzer = ImageAnalysis.Builder().build().also {
                it.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                    val mediaImage = imageProxy.image
                    if (mediaImage != null) {
                        val image = InputImage.fromMediaImage(
                            mediaImage,
                            imageProxy.imageInfo.rotationDegrees
                        )
                        barcodeScanner.process(image)
                            .addOnSuccessListener { barcodes ->
                                barcodes.forEach { barcode ->
                                    barcode.rawValue?.let { value ->
                                        try {
                                            val json = JSONObject(value)
                                            val studentId = json.getString("studentUsername")
                                            val dateTime = LocalDateTime.parse(
                                                json.getString("dateTime"),
                                                DateTimeFormatter.ISO_LOCAL_DATE_TIME
                                            )
                                            onQrScanned(studentId, dateTime)
                                        } catch (e: Exception) {
                                            onError(R.string.invalid_qr)
                                        }
                                    }
                                }
                            }
                            .addOnFailureListener {
                                onError(R.string.error_read_qr)
                            }
                            .addOnCompleteListener {
                                imageProxy.close()
                            }
                    } else {
                        imageProxy.close()
                    }
                }
            }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                // Unbind all use cases before rebinding
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageAnalyzer
                )
            } catch (exc: Exception) {
                onError(R.string.error_init_camera)
            }

            previewView
        },
        modifier = Modifier.fillMaxSize()
    )
}

// Handle camera permission request and delegate to QRScannerScreen if granted
@Composable
fun QRScannerWithPermission(
    onQrScanned: (String, LocalDateTime) -> Unit,
    onError: (Int) -> Unit
) {
    var permissionGranted by remember { mutableStateOf(false) }

    CameraPermissionHandler(
        onPermissionGranted = { permissionGranted = true },
        onPermissionDenied = { onError(R.string.permission_denied) }
    )

    if (permissionGranted) {
        QRScannerScreen(onQrScanned = onQrScanned, onError = onError)
    }
}

// Request camera permission using Activity Result API
@Composable
fun CameraPermissionHandler(
    onPermissionGranted: () -> Unit,
    onPermissionDenied: () -> Unit
) {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) onPermissionGranted() else onPermissionDenied()
    }

    LaunchedEffect(Unit) {
        when (PackageManager.PERMISSION_GRANTED) {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) -> {
                onPermissionGranted()
            }
            else -> {
                permissionLauncher.launch(android.Manifest.permission.CAMERA)
            }
        }
    }
}

// Dialog showing a list of assistance times or loading spinner
@SuppressLint("RememberReturnType")
@Composable
fun AssistanceListDialog(
    onDismiss: () -> Unit,
    assistanceList: List<LocalDateTime>,
    assistanceUiState: AssistanceUiState
) {
    val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.close))
            }
        },
        title = { Text(stringResource(R.string.assistance_list)) },
        text = {
            when (assistanceUiState) {
                AssistanceUiState.Loading -> {
                    CircularProgressIndicator()
                }
                AssistanceUiState.Success -> {
                    LazyColumn {
                        items(assistanceList) { dateTime ->
                            Text(stringResource(R.string.assistance_registered, dateTime.format(formatter)))
                        }
                    }
                }
            }
        }
    )
}