package es.iesfernandoaguilar.utils

import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.models.objects.ErrorHandler
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException

object PasswordUtils {

    // Convert byte array to hex string
    private fun bytesToHex(bytes: ByteArray): String {
        return buildString {
            for (byte in bytes) {
                // Mask byte to unsigned int, add 0x100 to keep leading zeros, then take substring
                append(((byte.toInt() and 0xff) + 0x100).toString(16).substring(1))
            }
        }
    }

    // Generate SHA-512 hash of a password with salt
    fun generateSHA512Hash(passwordToHash: String, salt: String): String? {
        return try {
            val md = MessageDigest.getInstance("SHA-512").apply {
                update(salt.toByteArray(StandardCharsets.UTF_8))
            }
            val hashedBytes = md.digest(passwordToHash.toByteArray(StandardCharsets.UTF_8))
            bytesToHex(hashedBytes)
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
            null
        }
    }

    // Verify password strength according to rules
    fun verifyPassword(password: String): Boolean {
        if (password.length < 7) {
            ErrorHandler.showError(R.string.dont_min_password_length)
            return false
        }
        if (!password.any { it.isUpperCase() }) {
            ErrorHandler.showError(R.string.dont_min_password_uppercase)
            return false
        }
        if (!password.any { it.isLowerCase() }) {
            ErrorHandler.showError(R.string.dont_min_password_lowercase)
            return false
        }
        return true
    }
}
