package es.iesfernandoaguilar.models.network

import es.iesfernandoaguilar.models.enums.TypeMessage

data class Message(val type: TypeMessage, val args: List<String>) {

    // Secondary constructor to allow vararg usage
    constructor(type: TypeMessage, vararg args: String) : this(type, args.toList())

    override fun toString(): String {
        return "Message(type=$type, args=$args)"
    }
}