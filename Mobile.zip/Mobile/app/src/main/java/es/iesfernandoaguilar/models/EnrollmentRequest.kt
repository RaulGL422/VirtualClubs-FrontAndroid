package es.iesfernandoaguilar.models

import java.time.LocalDateTime

data class EnrollmentRequest(
    val idEnrollmentRequest: Long,
    val classData: Class,
    val dateOfRequest: LocalDateTime
)