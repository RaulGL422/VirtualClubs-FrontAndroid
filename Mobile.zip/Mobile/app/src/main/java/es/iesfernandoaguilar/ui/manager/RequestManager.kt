package es.iesfernandoaguilar.ui.manager

import dagger.Lazy
import es.iesfernandoaguilar.models.Class
import es.iesfernandoaguilar.models.EnrollmentRequest
import es.iesfernandoaguilar.models.Request
import es.iesfernandoaguilar.models.Student
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.viewmodel.HomeViewModel
import es.iesfernandoaguilar.utils.ClubSerializerUtils
import es.iesfernandoaguilar.utils.EnrollmentRequestUtils
import es.iesfernandoaguilar.utils.RequestSerializerUtils
import javax.inject.Inject

class RequestManager @Inject constructor(
    private val connectionManager: Lazy<ConnectionManager>
) {

    // Request all club inscription requests for the current user
    fun requestAllInscriptionRequestToClubs() {
        connectionManager.get().sendRequestsToInscriptionRequest()
    }

    // Deserialize and pass request list to HomeViewModel
    suspend fun getRequestList(request: String) {
        val requestList = RequestSerializerUtils.deserializeRequestList(request) { club ->
            ClubSerializerUtils.deserializeClub(club) {
                connectionManager.get().requestPhoto(it)
            }
        }

        (ViewModelActive.getActive() as? HomeViewModel)?.updateRequestInformation(requestList)
    }

    // Accept a request to join a club
    fun acceptRequest(request: Request) {
        connectionManager.get().sendAcceptRequest(request.id)
    }

    // Decline a request to join a club
    fun declineRequest(request: Request) {
        connectionManager.get().sendDeclineRequest(request.id)
    }

    // Send a new inscription request to a club
    fun sendRequest(idClub: Long, userName: String) {
        connectionManager.get().sendNewInscriptionRequest(idClub, userName)
    }

    // Request all class enrollment requests
    fun requestEnrollmentRequests() {
        connectionManager.get().sendRequestEnrollmentRequests()
    }

    // Request students who are eligible to join a class
    fun requestStudentsCanJoinClass(clazz: Class) {
        connectionManager.get().sendRequestStudentsCanJoinClass(clazz.idClass)
    }

    // Send an enrollment request for a student to join a class
    fun sendEnrollmentRequest(clazz: Class, student: Student) {
        connectionManager.get().sendEnrollmentRequest(student.id, clazz.idClass)
    }

    // Accept an enrollment request
    fun acceptEnrollmentRequest(request: EnrollmentRequest) {
        connectionManager.get().sendAcceptEnrollmentRequest(request.idEnrollmentRequest)
    }

    // Decline an enrollment request
    fun declineEnrollmentRequest(request: EnrollmentRequest) {
        connectionManager.get().sendDeclineEnrollmentRequest(request.idEnrollmentRequest)
    }

    // Deserialize and pass enrollment request list to HomeViewModel
    fun enrollmentRequestList(enrollmentRequestListInfo: String) {
        val requestList = EnrollmentRequestUtils.deserializeEnrollmentRequestList(enrollmentRequestListInfo)

        (ViewModelActive.getActive() as? HomeViewModel)?.updateEnrollmentRequests(requestList)
    }
}
