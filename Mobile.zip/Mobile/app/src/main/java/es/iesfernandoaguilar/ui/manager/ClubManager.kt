package es.iesfernandoaguilar.ui.manager

import dagger.Lazy
import es.iesfernandoaguilar.models.Club
import es.iesfernandoaguilar.models.ClubComplete
import es.iesfernandoaguilar.models.Student
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.viewmodel.ClubViewModel
import es.iesfernandoaguilar.ui.viewmodel.HomeViewModel
import es.iesfernandoaguilar.utils.ClubSerializerUtils
import javax.inject.Inject

class ClubManager @Inject constructor(
    private val connectionManager: Lazy<ConnectionManager>
) {

    // Request clubs where the current user is a member
    fun requestClubsResumeInformation() {
        connectionManager.get().requestUserClubResume()
    }

    // Load full club details into the current ClubViewModel
    fun manageClubInfo(clubComplete: ClubComplete) {
        (ViewModelActive.getActive() as? ClubViewModel)?.setClubInfo(clubComplete)
    }

    // Deserialize and load personal and inscribed clubs into the HomeViewModel
    suspend fun manageClubsResumeInfo(personalClub: String, clubList: String) {
        val personal: Club? = if (personalClub.isNotBlank()) {
            ClubSerializerUtils.deserializeClub(personalClub) {
                connectionManager.get().requestPhoto(it)
            }
        } else null

        val inscribedClubs = ClubSerializerUtils.deserializeClubList(clubList) {
            connectionManager.get().requestPhoto(it)
        }

        (ViewModelActive.getActive() as? HomeViewModel)?.updateClubInformation(personal, inscribedClubs)
    }

    // Request complete information about a specific club
    fun requestClubInfo(clubId: Long) {
        connectionManager.get().requestCompleteClubInfo(clubId)
    }

    // Unlink a student from a specific club
    fun unLinkStudent(student: Student, club: ClubComplete) {
        connectionManager.get().unLinkStudent(student.id, club.id)
    }
}