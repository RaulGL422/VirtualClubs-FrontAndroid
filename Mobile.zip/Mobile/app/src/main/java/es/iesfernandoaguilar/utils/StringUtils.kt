package es.iesfernandoaguilar.utils

object StringUtils {

    // Splits the input string by commas, ignoring commas inside quotes or braces
    fun smartSplit(input: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var inBraces = 0

        var i = 0
        while (i < input.length) {
            val char = input[i]

            when (char) {
                '"' -> {
                    inQuotes = !inQuotes  // Toggle quotes state
                    current.append(char)
                }
                '{' -> {
                    inBraces++            // Entering braces block
                    current.append(char)
                }
                '}' -> {
                    inBraces--            // Exiting braces block
                    current.append(char)
                }
                ',' -> {
                    // Split only if not inside quotes or braces
                    if (!inQuotes && inBraces == 0) {
                        result.add(current.toString().trim())
                        current.clear()
                    } else {
                        current.append(char)
                    }
                }
                else -> current.append(char)
            }

            i++
        }

        // Add last collected part if exists
        if (current.isNotEmpty()) result.add(current.toString().trim())
        return result
    }
}
