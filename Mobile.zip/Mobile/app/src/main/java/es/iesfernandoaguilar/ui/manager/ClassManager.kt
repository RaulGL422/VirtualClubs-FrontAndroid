package es.iesfernandoaguilar.ui.manager

import dagger.Lazy
import es.iesfernandoaguilar.models.Class
import es.iesfernandoaguilar.models.ClassComplete
import es.iesfernandoaguilar.models.Student
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.viewmodel.ClassViewModel
import es.iesfernandoaguilar.ui.viewmodel.ClubViewModel
import es.iesfernandoaguilar.ui.viewmodel.HomeViewModel
import es.iesfernandoaguilar.utils.AssistanceUtils
import es.iesfernandoaguilar.utils.ClassUtils
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import javax.inject.Inject

class ClassManager @Inject constructor(
    private val connectionManager: Lazy<ConnectionManager>
) {

    fun requestClasses() {
        connectionManager.get().sendRequestEnrollmentClasses()
    }

    fun requestPublicClasses() {
        connectionManager.get().requestPublicClasses()
    }

    fun requestCompleteClassInfo(clazz: Class) {
        connectionManager.get().sendRequestClassInfo(clazz.idClass)
    }

    fun joinToPublicClass(clazz: Class) {
        connectionManager.get().sendJoinPublicClass(clazz.idClass)
    }

    fun completeClassInfo(clazz: ClassComplete) {
        (ViewModelActive.getActive() as? ClassViewModel)?.loadCompleteClassInfo(clazz)
    }

    fun classList(classListInfo: String) {
        val classes = ClassUtils.deserializeClassList(classListInfo)

        when (val vm = ViewModelActive.getActive()) {
            is HomeViewModel -> vm.updateClassList(classes)
            is ClubViewModel -> vm.updateClassList(classes)
        }
    }

    fun publicClassList(classListInfo: String) {
        val classes = ClassUtils.deserializeClassList(classListInfo)

        (ViewModelActive.getActive() as? HomeViewModel)?.updatePublicClasses(classes)
    }

    fun sendAssistance(classId: Long, studentUserName: String, dateTime: LocalDateTime) {
        connectionManager.get().sendAssistance(classId, studentUserName, dateTime)
    }

    fun isClassFinished(c: Class): Boolean {
        val today = LocalDate.now()
        val now = LocalTime.now()

        return if (c.uniqueDate) {
            // Handle single-day classes
            c.uniqueDateDay?.let {
                today.isAfter(it) || (today.isEqual(it) && now.isAfter(c.endTime))
            } != false
        } else {
            // Handle repeating classes
            val endDate = c.repeatUntilDate ?: return true
            when {
                today.isAfter(endDate) -> true
                today.isEqual(endDate) -> {
                    val todayDay = today.dayOfWeek
                    c.weekDays?.contains(todayDay) != true || now.isAfter(c.endTime)
                }
                else -> false
            }
        }
    }

    fun requestAssistance(clazz: ClassComplete, userName: String) {
        connectionManager.get().requestAssistance(clazz.idClass, userName)
    }

    fun updateAssistance(assistance: String) {
        val list = AssistanceUtils.deserializeAssistance(assistance)
        (ViewModelActive.getActive() as? ClassViewModel)?.updateAssistance(list)
    }

    fun unLinkStudent(clazz: ClassComplete, student: Student) {
        connectionManager.get().unLinkClassStudent(clazz.idClass, student.id)
    }
}
