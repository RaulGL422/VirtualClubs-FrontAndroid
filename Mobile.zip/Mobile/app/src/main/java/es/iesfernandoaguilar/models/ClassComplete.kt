package es.iesfernandoaguilar.models

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

data class ClassComplete(
    override val idClass: Long,
    override val clubName: String,
    override val roomName: String,
    override val instructorName: String,
    override val name: String,
    override val description: String,
    override val startTime: LocalTime,
    override val endTime: LocalTime,
    override val uniqueDate: Boolean,
    override val uniqueDateDay: LocalDate?,
    override val weekDays: Set<DayOfWeek>?,
    override val repeatUntilDate: LocalDate?,
    override val public: Boolean,
    var canManage: Boolean,
    val ageRestricted: Boolean,
    val minAge: Int?,
    val maxAge: Int?,
    val students: List<Student>
) : Class(
    idClass, clubName, roomName, instructorName, name, description, startTime, endTime, uniqueDate, uniqueDateDay, weekDays,
    repeatUntilDate, public
)