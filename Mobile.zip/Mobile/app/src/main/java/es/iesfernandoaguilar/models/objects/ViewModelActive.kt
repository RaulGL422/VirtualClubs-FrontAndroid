package es.iesfernandoaguilar.models.objects

import es.iesfernandoaguilar.models.ViewModelControl

object ViewModelActive {
    private var activeViewModel: ViewModelControl? = null

    fun setActive(viewModel: ViewModelControl) {
        activeViewModel = viewModel
    }

    fun getActive(): ViewModelControl? = activeViewModel
}