package es.iesfernandoaguilar.models

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

open class Class(
    open val idClass: Long,
    open val clubName: String,
    open val roomName: String,
    open val instructorName: String,
    open val name: String,
    open val description: String,
    open val startTime: LocalTime,
    open val endTime: LocalTime,
    open val uniqueDate: Boolean,
    open val uniqueDateDay: LocalDate?,
    open val weekDays: Set<DayOfWeek>?,
    open val repeatUntilDate: LocalDate?,
    open val public: Boolean
)