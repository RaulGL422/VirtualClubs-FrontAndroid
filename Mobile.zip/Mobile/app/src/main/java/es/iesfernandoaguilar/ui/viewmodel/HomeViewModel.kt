package es.iesfernandoaguilar.ui.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import es.iesfernandoaguilar.models.Class
import es.iesfernandoaguilar.models.Club
import es.iesfernandoaguilar.models.EnrollmentRequest
import es.iesfernandoaguilar.models.Request
import es.iesfernandoaguilar.models.ViewModelControl
import es.iesfernandoaguilar.models.objects.SessionData
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.manager.ClassManager
import es.iesfernandoaguilar.ui.manager.ClubManager
import es.iesfernandoaguilar.ui.manager.RequestManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val clubManager: ClubManager,
    private val classManager: ClassManager,
    private val requestManager: RequestManager
) : ViewModelControl, ViewModel() {

    // UI states for each data group
    var homeUiStateClass: HomeUiStateClass by mutableStateOf(HomeUiStateClass.Loading)
        private set

    var homeUiStateClub: HomeUiStateClub by mutableStateOf(HomeUiStateClub.Loading)
        private set

    var homeUiStateRequest: HomeUiStateRequest by mutableStateOf(HomeUiStateRequest.Loading)
        private set

    var homeUiStateEnrollmentRequest: HomeUiStateEnrollmentRequest by mutableStateOf(HomeUiStateEnrollmentRequest.Loading)
        private set

    var homeUiStatePublicClasses: HomeUiStatePublicClasses by mutableStateOf(HomeUiStatePublicClasses.Loading)
        private set

    // Centralized state holder (immutable data)
    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state.asStateFlow()

    init {
        // Clear session selections
        SessionData.clubSelected = null
        SessionData.classSelected = null

        ViewModelActive.setActive(this)

        // Start loading all data
        requestData()
    }

    // Request all required data concurrently
    fun requestData() {
        ViewModelActive.setActive(this)
        viewModelScope.launch {
            // Set all UI states to loading
            homeUiStateClub = HomeUiStateClub.Loading
            homeUiStateClass = HomeUiStateClass.Loading
            homeUiStateRequest = HomeUiStateRequest.Loading
            homeUiStateEnrollmentRequest = HomeUiStateEnrollmentRequest.Loading
            homeUiStatePublicClasses = HomeUiStatePublicClasses.Loading

            // Launch all requests in parallel
             clubManager.requestClubsResumeInformation()
             classManager.requestClasses()
             classManager.requestPublicClasses()
            requestManager.requestAllInscriptionRequestToClubs()
            requestManager.requestEnrollmentRequests()
        }
    }

    // Update clubs and personal club data
    fun updateClubInformation(personalClub: Club?, clubs: List<Club>) {
        Log.i("HomeViewModel", "Loaded Clubs: ${clubs.size}")
        Log.i("HomeViewModel", "Personal Club found: ${personalClub != null}")

        _state.value = _state.value.copy(
            personalClub = personalClub,
            clubList = clubs
        )
        homeUiStateClub = HomeUiStateClub.Success
    }

    // Update enrollment requests
    fun updateEnrollmentRequests(enrollmentRequests: List<EnrollmentRequest>) {
        Log.i("HomeViewModel", "Loaded Enrollment Requests: ${enrollmentRequests.size}")

        _state.value = _state.value.copy(
            enrollmentRequestList = enrollmentRequests
        )
        homeUiStateEnrollmentRequest = HomeUiStateEnrollmentRequest.Success
    }

    // Update public classes list
    fun updatePublicClasses(publicClasses: List<Class>) {
        Log.i("HomeViewModel", "Loaded Public Classes: ${publicClasses.size}")

        _state.value = _state.value.copy(
            publicClasses = publicClasses
        )
        homeUiStatePublicClasses = HomeUiStatePublicClasses.Success
    }

    // Update class list, separating finished and unfinished classes
    fun updateClassList(classes: List<Class>) {
        Log.i("HomeViewModel", "Loaded Classes: ${classes.size}")

        val finished = classes.filter { classManager.isClassFinished(it) }
        val notFinished = classes - finished

        _state.value = _state.value.copy(
            classList = notFinished,
            finishedClasses = finished
        )
        homeUiStateClass = HomeUiStateClass.Success
    }

    // Update club requests
    fun updateRequestInformation(requests: List<Request>) {
        Log.i("HomeViewModel", "Loaded Requests: ${requests.size}")

        _state.value = _state.value.copy(requestList = requests)
        homeUiStateRequest = HomeUiStateRequest.Success
    }

    // Actions to join or handle requests with logs
    fun joinIntoPublicClass(clazz: Class) {
        Log.i("HomeViewModel", "Joining Public Class: ${clazz.name}")
        classManager.joinToPublicClass(clazz)
    }

    fun acceptEnrollmentRequest(request: EnrollmentRequest) {
        Log.i("HomeViewModel", "Accept Enrollment Request: ${request.classData.name}")
        requestManager.acceptEnrollmentRequest(request)
    }

    fun declineEnrollmentRequest(request: EnrollmentRequest) {
        Log.i("HomeViewModel", "Decline Enrollment Request: ${request.classData.name}")
        requestManager.declineEnrollmentRequest(request)
    }

    fun acceptRequest(request: Request) {
        Log.i("HomeViewModel", "Accept Request: ${request.club.name}")
        requestManager.acceptRequest(request)
    }

    fun declineRequest(request: Request) {
        Log.i("HomeViewModel", "Decline Request: ${request.club.name}")
        requestManager.declineRequest(request)
    }
}

// Immutable state data class
data class HomeState(
    val personalClub: Club? = null,
    val clubList: List<Club> = emptyList(),
    val classList: List<Class> = emptyList(),
    val finishedClasses: List<Class> = emptyList(),
    val enrollmentRequestList: List<EnrollmentRequest> = emptyList(),
    val requestList: List<Request> = emptyList(),
    val publicClasses: List<Class> = emptyList(),
)

// UI state sealed interfaces
sealed interface HomeUiStateClub {
    data object Success : HomeUiStateClub
    data object Loading : HomeUiStateClub
}

sealed interface HomeUiStateClass {
    data object Success : HomeUiStateClass
    data object Loading : HomeUiStateClass
}

sealed interface HomeUiStateRequest {
    data object Success : HomeUiStateRequest
    data object Loading : HomeUiStateRequest
}

sealed interface HomeUiStateEnrollmentRequest {
    data object Success : HomeUiStateEnrollmentRequest
    data object Loading : HomeUiStateEnrollmentRequest
}

sealed interface HomeUiStatePublicClasses {
    data object Success : HomeUiStatePublicClasses
    data object Loading : HomeUiStatePublicClasses
}
