package es.iesfernandoaguilar.ui.pages

import android.app.DatePickerDialog
import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.MarkunreadMailbox
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.ui.ScreenType
import es.iesfernandoaguilar.ui.components.AppBar
import es.iesfernandoaguilar.ui.components.RoundedTextField
import es.iesfernandoaguilar.ui.navigation.Destination
import es.iesfernandoaguilar.ui.viewmodel.UserInformationViewModel
import java.util.Calendar

// Navigation destination for the user information screen
object UserInformationDestination : Destination {
    override val route = "userInformation"
    override val titleRes = R.string.userInformation
}

@Composable
fun UserInformationPage(
    onLogOut: () -> Unit,
    onSettingsPressed: () -> Unit,
    @StringRes title: Int,
    viewModel: UserInformationViewModel = hiltViewModel(),
    screenType: ScreenType,
) {
    // Collect the current form state from the ViewModel
    val formState by viewModel.formState.collectAsState()

    val context = LocalContext.current

    // Gender options as strings
    val genderOptions = listOf(
        stringResource(R.string.male),
        stringResource(R.string.female),
        stringResource(R.string.other)
    )

    // Determine the selected gender index based on current form state
    val selectedGenderIndex = when (formState.gender) {
        genderOptions[0] -> 0
        genderOptions[1] -> 1
        else -> 2
    }

    // Local state for selected gender to avoid recomposition loops
    var selectedGender by remember { mutableIntStateOf(selectedGenderIndex) }

    // Local state for the "Other" gender input text
    var otherGender by remember { mutableStateOf(if (selectedGender == 2) formState.gender else "") }

    // Calendar instance for DatePickerDialog default date
    val calendar = Calendar.getInstance()

    Scaffold(
        topBar = {
            AppBar(
                canGoBack = false,
                titleResId = title,
                actions = {
                    // Logout button
                    IconButton(onClick = onLogOut) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = stringResource(R.string.logout))
                    }
                    Spacer(Modifier.width(10.dp))
                    // Settings button
                    IconButton(onClick = onSettingsPressed) {
                        Icon(Icons.Default.Settings, contentDescription = stringResource(R.string.settings_page))
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Width modifier depending on screen size
            val contentWidth = when (screenType) {
                ScreenType.Medium -> 0.5f
                ScreenType.Small -> 0.8f
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth(contentWidth)
                    .align(Alignment.Center)
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                // Title and subtitle texts
                Text(
                    text = stringResource(R.string.profile_info_title),
                    style = MaterialTheme.typography.headlineSmall
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.profile_info_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(24.dp))

                // Name input field
                RoundedTextField(
                    value = formState.name,
                    onValueChange = viewModel::onNameChanged,
                    placeholder = R.string.name,
                    leadingIcon = Icons.Default.Person
                )
                Spacer(Modifier.height(16.dp))

                // Surname input field
                RoundedTextField(
                    value = formState.surname,
                    onValueChange = viewModel::onSurnameChanged,
                    placeholder = R.string.surname,
                    leadingIcon = Icons.Default.Person
                )
                Spacer(Modifier.height(16.dp))

                // Phone number input field
                RoundedTextField(
                    value = formState.phoneNumber,
                    onValueChange = viewModel::onPhoneNumberChanged,
                    placeholder = R.string.phonenumber,
                    leadingIcon = Icons.Default.Phone,
                    keyboardType = KeyboardType.Phone
                )
                Spacer(Modifier.height(16.dp))

                // Date of birth field with a DatePickerDialog on click
                Box {
                    RoundedTextField(
                        value = formState.dateOfBirth,
                        onValueChange = { /* read-only */ },
                        placeholder = R.string.dateofbirth,
                        readOnly = true,
                        leadingIcon = Icons.Default.DateRange
                    )
                    Spacer(
                        modifier = Modifier
                            .matchParentSize()
                            .clickable {
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val dateString = "%04d-%02d-%02d".format(year, month + 1, dayOfMonth)
                                        viewModel.onDateOfBirthChanged(dateString)
                                    },
                                    calendar.get(Calendar.YEAR),
                                    calendar.get(Calendar.MONTH),
                                    calendar.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }
                    )
                }
                Spacer(Modifier.height(16.dp))

                // Gender selection label
                Text(
                    text = stringResource(R.string.gender),
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(Modifier.height(8.dp))

                // Gender options displayed horizontally or vertically based on screen type
                if (screenType == ScreenType.Medium) {
                    Row {
                        genderOptions.forEachIndexed { index, option ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        selectedGender = index
                                        if (index != 2) {
                                            viewModel.onGenderChanged(option)
                                            otherGender = ""
                                        } else {
                                            // When "Other" selected, clear gender in ViewModel
                                            viewModel.onGenderChanged("")
                                        }
                                    }
                            ) {
                                RadioButton(
                                    selected = selectedGender == index,
                                    onClick = {
                                        selectedGender = index
                                        if (index != 2) {
                                            viewModel.onGenderChanged(option)
                                            otherGender = ""
                                        } else {
                                            viewModel.onGenderChanged("")
                                        }
                                    }
                                )
                                Text(option)
                            }
                        }
                    }
                } else {
                    Column {
                        genderOptions.forEachIndexed { index, option ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedGender = index
                                        if (index != 2) {
                                            viewModel.onGenderChanged(option)
                                            otherGender = ""
                                        } else {
                                            viewModel.onGenderChanged("")
                                        }
                                    }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = selectedGender == index,
                                    onClick = {
                                        selectedGender = index
                                        if (index != 2) {
                                            viewModel.onGenderChanged(option)
                                            otherGender = ""
                                        } else {
                                            viewModel.onGenderChanged("")
                                        }
                                    }
                                )
                                Text(option)
                            }
                        }
                    }
                }

                // Show custom "Other gender" input only when "Other" is selected
                if (selectedGender == 2) {
                    Spacer(Modifier.height(12.dp))
                    RoundedTextField(
                        value = otherGender,
                        onValueChange = {
                            otherGender = it
                            viewModel.onGenderChanged(it)
                        },
                        placeholder = R.string.especify_gender,
                        leadingIcon = Icons.Filled.AssignmentInd
                    )
                }

                Spacer(Modifier.height(16.dp))

                // Address input field
                RoundedTextField(
                    value = formState.address,
                    onValueChange = viewModel::onAddressChanged,
                    placeholder = R.string.address,
                    leadingIcon = Icons.Default.Home
                )
                Spacer(Modifier.height(16.dp))

                // City input field
                RoundedTextField(
                    value = formState.city,
                    onValueChange = viewModel::onCityChanged,
                    placeholder = R.string.city,
                    leadingIcon = Icons.Default.LocationCity
                )
                Spacer(Modifier.height(16.dp))

                // Postal code input field
                RoundedTextField(
                    value = formState.postalCode,
                    onValueChange = viewModel::onPostalCodeChanged,
                    placeholder = R.string.postalcode,
                    keyboardType = KeyboardType.Number,
                    leadingIcon = Icons.Default.MarkunreadMailbox
                )
                Spacer(Modifier.height(24.dp))

                // Submit button to send the form
                Button(
                    onClick = { viewModel.sendInfo() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.send))
                }
            }
        }
    }
}
