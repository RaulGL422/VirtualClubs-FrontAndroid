package es.iesfernandoaguilar.ui.manager

import dagger.Lazy
import es.iesfernandoaguilar.models.Student
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.viewmodel.ClassViewModel
import java.time.LocalDate
import javax.inject.Inject

class UserManager @Inject constructor(
    private val connectionManager: Lazy<ConnectionManager>
) {

    // Sends updated user info to the server
    fun sendUserInfo(
        name: String,
        surname: String,
        phoneNumber: String,
        dateOfBirth: LocalDate,
        gender: String,
        address: String,
        city: String,
        postalCode: String
    ) {
        connectionManager.get().sendUpdateUserInfo(
            name,
            surname,
            phoneNumber,
            dateOfBirth,
            gender,
            address,
            city,
            postalCode
        )
    }

    // Requests an activation code for the user
    fun requestUserActiveCode() {
        connectionManager.get().requestActiveCode()
    }

    // Sends the activation code entered by the user
    fun sendCode(code: String) {
        connectionManager.get().sendActiveUserCode(code)
    }

    // Passes the list of students who can join the class to the active ClassViewModel if present
    fun usersCanJoinIntoClass(userList: List<Student>) {
        val activeViewModel = ViewModelActive.getActive() as? ClassViewModel ?: return
        activeViewModel.loadStudentsToRequest(userList)
    }
}
