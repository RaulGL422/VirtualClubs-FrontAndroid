package es.iesfernandoaguilar.utils

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object AssistanceUtils {
    private val formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME

    fun deserializeAssistance(data: String): List<LocalDateTime> {
        // check minimal length and braces presence
        if (data.length < 2 || data.first() != '{' || data.last() != '}') return emptyList()

        // Extract inner content between braces
        val content = data.substring(1, data.length - 1).trim()
        if (content.isEmpty()) return emptyList()

        // Split by commas and map to LocalDateTime in a single pass
        return content.split(',')
            .asSequence() // use sequence for lazy processing
            .map { it.trim() }
            .map { LocalDateTime.parse(it, formatter) }
            .toList()
    }
}