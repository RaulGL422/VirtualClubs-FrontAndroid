package es.iesfernandoaguilar.ui.pages

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MailLock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.models.objects.ErrorHandler
import es.iesfernandoaguilar.models.objects.NotifyHandler
import es.iesfernandoaguilar.ui.ScreenType
import es.iesfernandoaguilar.ui.components.RoundedTextField
import es.iesfernandoaguilar.ui.navigation.Destination
import es.iesfernandoaguilar.ui.viewmodel.ActiveUserViewModel
import kotlinx.coroutines.delay

// Navigation destination for the active user screen
object ActiveUserDestination : Destination {
    override val route = "activeUser"
    override val titleRes = R.string.activeUser
}

@Composable
fun ActiveUserPage(
    viewModel: ActiveUserViewModel = hiltViewModel(),
    onSettingsTap: () -> Unit,
    onBack: () -> Unit,
    screenType: ScreenType
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onSettingsTap,
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = stringResource(R.string.settings_page)
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ) { paddingValues ->
        // Gradient background with centered card
        Box(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.outline,
                            MaterialTheme.colorScheme.outlineVariant
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            ActiveUserCard(
                codeValue = state.code,
                onCodeChange = viewModel::onCodeChanged,
                onRequestNewCode = viewModel::requestNewCode,
                onVerifyCode = viewModel::sendCode,
                onBack = onBack,
                screenType = screenType
            )
        }
    }
}

@Composable
fun ActiveUserCard(
    codeValue: String,
    onCodeChange: (String) -> Unit,
    onRequestNewCode: () -> Unit,
    onVerifyCode: () -> Unit,
    onBack: () -> Unit,
    screenType: ScreenType
) {
    val errorMessage = ErrorHandler.errorMessage
    val notifyMessage = NotifyHandler.notifyMessage

    Card(
        modifier = Modifier
            .fillMaxWidth(0.85f)
            .wrapContentHeight(),
        shape = MaterialTheme.shapes.medium,
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Back button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Title
            Text(
                text = stringResource(R.string.verify_user),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Text input for the verification code
            RoundedTextField(
                value = codeValue,
                onValueChange = onCodeChange,
                placeholder = R.string.code,
                leadingIcon = Icons.Filled.MailLock
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Show error or notification message
            (errorMessage ?: notifyMessage)?.let {
                Text(
                    text = stringResource(it),
                    color = if (errorMessage != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Show buttons horizontally or vertically depending on screen size
            if (screenType == ScreenType.Medium) {
                Row(
                    modifier = Modifier.padding(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CountdownButton(
                        onClick = onRequestNewCode,
                        modifier = Modifier.weight(1f).height(48.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = onVerifyCode,
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Text(stringResource(R.string.send_code))
                    }
                }
            } else {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CountdownButton(onClick = onRequestNewCode)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = onVerifyCode) {
                        Text(stringResource(R.string.send_code))
                    }
                }
            }
        }
    }
}

@Composable
fun CountdownButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    var timeLeft by remember { mutableIntStateOf(60) }
    var isCounting by remember { mutableStateOf(true) }

    // Launch countdown effect when counting starts
    LaunchedEffect(isCounting) {
        if (isCounting) {
            while (timeLeft > 0) {
                delay(1000)
                timeLeft--
            }
            isCounting = false
        }
    }

    OutlinedButton(
        onClick = {
            onClick()
            timeLeft = 60
            isCounting = true
        },
        modifier = modifier,
        enabled = !isCounting
    ) {
        // Show countdown or button text
        Text(
            text = if (isCounting)
                stringResource(R.string.count_down_resend_code, timeLeft)
            else
                stringResource(R.string.resend_code)
        )
    }
}