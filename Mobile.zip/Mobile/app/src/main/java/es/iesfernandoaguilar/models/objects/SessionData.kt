package es.iesfernandoaguilar.models.objects

import es.iesfernandoaguilar.models.Class
import es.iesfernandoaguilar.models.Club
import es.iesfernandoaguilar.models.User

object SessionData {
    var currentUser: User? = null
    var clubSelected: Club? = null
    var classSelected: Class? = null
    var autoLoginActive: Boolean = false
    var passWord: String = ""
}