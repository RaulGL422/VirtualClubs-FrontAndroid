package es.iesfernandoaguilar.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import es.iesfernandoaguilar.models.objects.ErrorHandler
import es.iesfernandoaguilar.models.objects.NotifyHandler
import es.iesfernandoaguilar.models.objects.SessionData
import es.iesfernandoaguilar.ui.manager.ConnectionManager
import es.iesfernandoaguilar.ui.manager.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GlobalNavViewModel @Inject constructor(
    private val sessionManager: SessionManager,
   private val connectionManager: ConnectionManager
) : ViewModel() {
    private val _navRoute = MutableStateFlow<String?>(null)
    val navRoute: StateFlow<String?> = _navRoute

    init {
        viewModelScope.launch {
            // Reset notify and errors
            ErrorHandler.clear()
            NotifyHandler.clear()

            connectionManager.navigationCommands.collect { route ->
                _navRoute.value = route
            }
        }
    }

    fun logout() {
        // Set Default values to Session Data
        SessionData.currentUser = null
        SessionData.passWord = ""
        SessionData.autoLoginActive = false

        sessionManager.clearAutoUserLogin() // Clear Auto Login

        connectionManager.logout() // Send to close connection
    }

    fun resetRoute() {
        _navRoute.value = null
    }
}