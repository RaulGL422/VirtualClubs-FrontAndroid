package es.iesfernandoaguilar.utils

import es.iesfernandoaguilar.models.Class
import es.iesfernandoaguilar.models.ClassComplete
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

object ClassUtils {

    /**
     * Deserialize a class string into a Class object.
     * Expected format:
     * {id,name,description,clubName,instructorName,roomName,startTime,endTime,uniqueDate,uniqueDateDay,{weekdays},repeatUntilDate,public}
     */
    fun deserializeClass(clazz: String): Class {
        val parts = StringUtils.smartSplit(clazz.removePrefix("{").removeSuffix("}"))
        var i = 0

        val idClass = parts[i++].toLong()
        val name = parts[i++].removeSurrounding("\"")
        val description = parts[i++].removeSurrounding("\"")
        val clubName = parts[i++]
        val instructorName = parts[i++]
        val roomName = parts[i++]
        val startTime = LocalTime.parse(parts[i++])
        val endTime = LocalTime.parse(parts[i++])
        val uniqueDate = parts[i++].toBoolean()
        val uniqueDateDay = parts[i++].takeIf(String::isNotBlank)?.let(LocalDate::parse)

        val weekDays = parts[i++].takeIf(String::isNotBlank)
            ?.removePrefix("{")?.removeSuffix("}")
            ?.split(",")
            ?.mapNotNull { it.toIntOrNull()?.let(DayOfWeek::of) }
            ?.toSet()

        val repeatUntilDate = parts[i++].takeIf(String::isNotBlank)?.let(LocalDate::parse)
        val isPublic = parts[i].toBoolean()

        return Class(
            idClass = idClass,
            clubName = clubName,
            instructorName = instructorName,
            roomName = roomName,
            name = name,
            description = description,
            startTime = startTime,
            endTime = endTime,
            uniqueDate = uniqueDate,
            uniqueDateDay = uniqueDateDay,
            weekDays = weekDays,
            repeatUntilDate = repeatUntilDate,
            public = isPublic
        )
    }

    /**
     * Deserialize a class string into a ClassComplete object.
     * Starts reading weekday data at index 13.
     */
    fun deserializeClassComplete(clazz: String, students: String): ClassComplete {
        val parts = StringUtils.smartSplit(clazz.removePrefix("{").removeSuffix("}"))
        var i = 0

        val idClass = parts[i++].toLong()
        val clubName = parts[i++]
        val name = parts[i++].removeSurrounding("\"")
        val description = parts[i++].removeSurrounding("\"")
        val roomName = parts[i++]
        val instructorName = parts[i++]
        val ageRestricted = parts[i++].toBoolean()
        val minAge = parts[i++].toIntOrNull()
        val maxAge = parts[i++].toIntOrNull()
        val startTime = LocalTime.parse(parts[i++])
        val endTime = LocalTime.parse(parts[i++])
        val uniqueDate = parts[i++].toBoolean()
        val uniqueDateDay = parts[i++].takeIf(String::isNotBlank)?.let(LocalDate::parse)

        val weekDays = parts[i++].takeIf(String::isNotBlank)
            ?.removePrefix("{")?.removeSuffix("}")
            ?.split(",")
            ?.mapNotNull { it.toIntOrNull()?.let(DayOfWeek::of) }
            ?.toSet()

        val repeatUntilDate = parts[i++].takeIf(String::isNotBlank)?.let(LocalDate::parse)
        val isPublic = parts[i++].toBoolean()
        val canManage = parts[i].toBoolean()

        return ClassComplete(
            idClass = idClass,
            clubName = clubName,
            name = name,
            description = description,
            roomName = roomName,
            instructorName = instructorName,
            ageRestricted = ageRestricted,
            minAge = minAge,
            maxAge = maxAge,
            startTime = startTime,
            endTime = endTime,
            uniqueDate = uniqueDate,
            uniqueDateDay = uniqueDateDay,
            weekDays = weekDays,
            repeatUntilDate = repeatUntilDate,
            public = isPublic,
            canManage = canManage,
            students = UserUtils.deserializeUserList(students)
        )
    }

    /**
     * Deserialize a list of serialized Class objects from a string.
     * Input format: {{...},{...},{...}}
     */
    fun deserializeClassList(list: String): List<Class> {
        val trimmed = list.removePrefix("{").removeSuffix("}")

        if (trimmed.isBlank()) return emptyList()

        // Split the list into individual serialized class strings
        val classStrings = trimmed.split("},{").map {
            // Normalize each string to have curly braces
            "{${it.removePrefix("{").removeSuffix("}")}}"
        }

        return classStrings.map(::deserializeClass)
    }
}
