package es.iesfernandoaguilar.utils

import android.graphics.Bitmap
import androidx.core.graphics.createBitmap
import androidx.core.graphics.set
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter

object QRUtils {

    // Generates a QR code bitmap of given size with UTF-8 encoding
    fun generateQRCode(content: String, size: Int = 512): Bitmap {
        val writer = QRCodeWriter()
        val hints = mapOf(EncodeHintType.CHARACTER_SET to "UTF-8")
        val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size, hints)

        val bitmap = createBitmap(size, size, Bitmap.Config.RGB_565)
        val black = android.graphics.Color.BLACK
        val white = android.graphics.Color.WHITE

        for (x in 0 until size) {
            for (y in 0 until size) {
                val pixelColor = if (bitMatrix[x, y]) black else white
                bitmap[x, y] = pixelColor
            }
        }
        return bitmap
    }
}
