package es.iesfernandoaguilar.models

open class Club(
    open val id: Long,
    open val name: String,
    open val description: String,
    open val havePhoto: Boolean,
    open val photo: ByteArray?,
    open val address: String,
    open val city: String,
    open val postalCode: String
)