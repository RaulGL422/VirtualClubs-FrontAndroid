package es.iesfernandoaguilar.models

data class Student(
    val id: Long,
    val userName: String,
    val name: String,
    val surName: String,
    val email: String
)
