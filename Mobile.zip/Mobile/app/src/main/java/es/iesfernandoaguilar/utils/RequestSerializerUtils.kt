package es.iesfernandoaguilar.utils

import es.iesfernandoaguilar.models.Club
import es.iesfernandoaguilar.models.Request
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object RequestSerializerUtils {

    // Deserialize a list of Request objects asynchronously
    suspend fun deserializeRequestList(
        requestStringList: String,
        onDeserializeClub: suspend (String) -> Club
    ): List<Request> {
        if (requestStringList.isBlank()) return emptyList()

        val cleaned = requestStringList.removePrefix("{").removeSuffix("}")

        // Split list by "}," boundary, trim, and deserialize each
        return cleaned.split(Regex("(?<=\\}),"))
            .filter { it.isNotBlank() }
            .map { deserializeRequest(it.trim(), onDeserializeClub) }
    }

    // Deserialize a single Request from string asynchronously
    suspend fun deserializeRequest(
        requestString: String,
        onDeserializeClub: suspend (String) -> Club
    ): Request {
        val cleaned = requestString.removePrefix("{").removeSuffix("}")

        // Find the indexes of the first two commas to split fields
        val firstCommaIndex = cleaned.indexOf(',')
        val secondCommaIndex = cleaned.indexOf(',', firstCommaIndex + 1)

        if (firstCommaIndex == -1 || secondCommaIndex == -1) {
            throw IllegalArgumentException("Invalid request format: $requestString")
        }

        val idPart = cleaned.substring(0, firstCommaIndex)
        val fechaHoraPart = cleaned.substring(firstCommaIndex + 1, secondCommaIndex)
        val clubPart = cleaned.substring(secondCommaIndex + 1)

        val id = idPart.toLong()
        val fechaHora = LocalDateTime.parse(fechaHoraPart, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
        val club = onDeserializeClub(clubPart)

        return Request(
            id = id,
            date = fechaHora,
            club = club
        )
    }
}
