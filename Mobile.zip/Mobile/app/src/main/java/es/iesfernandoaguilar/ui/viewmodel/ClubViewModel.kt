package es.iesfernandoaguilar.ui.viewmodel

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import es.iesfernandoaguilar.models.Class
import es.iesfernandoaguilar.models.ClubComplete
import es.iesfernandoaguilar.models.Student
import es.iesfernandoaguilar.models.ViewModelControl
import es.iesfernandoaguilar.models.objects.SessionData
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.manager.ClassManager
import es.iesfernandoaguilar.ui.manager.ClubManager
import es.iesfernandoaguilar.ui.manager.RequestManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class ClubViewModel @Inject constructor(
    private val clubManager: ClubManager,
    private val classManager: ClassManager,
    private val requestManager: RequestManager
) : ViewModelControl, ViewModel() {

    // Club UI loading state
    var clubUiState: ClubUiState by mutableStateOf(ClubUiState.Loading)
        private set

    // Classes UI loading state
    var clubClassUiState: ClubClassUiState by mutableStateOf(ClubClassUiState.Loading)
        private set

    // Internal mutable state flow holding club data and classes
    private val _state = MutableStateFlow(ClubState())
    val state: StateFlow<ClubState> = _state.asStateFlow()

    init {
        // Register this ViewModel as active
        ViewModelActive.setActive(this)

        // Request initial club info and classes on init
        SessionData.clubSelected?.id?.let {
            clubManager.requestClubInfo(it)
        }
        classManager.requestClasses()
    }

    // Set club info and update UI state to success
    fun setClubInfo(club: ClubComplete) {
        Log.i("ClubViewModel", "Loaded Club -> ${club.name}")

        _state.value = _state.value.copy(club = club)
        clubUiState = ClubUiState.Success
    }

    // Update classes list, split finished and unfinished, then update state
    fun updateClassList(listClass: List<Class>) {
        Log.i("ClubViewModel", "Loaded Classes -> ${listClass.size} classes found")

        val (finished, notFinished) = listClass.partition { classManager.isClassFinished(it) }

        _state.value = _state.value.copy(
            classes = notFinished,
            finishedClasses = finished
        )

        clubClassUiState = ClubClassUiState.Success
    }

    // Send inscription request to club for given username
    fun sendRequest(userName: String) {
        Log.i("ClubViewModel", "Sending inscription request -> $userName")

        _state.value.club?.id?.let { clubId ->
            requestManager.sendRequest(clubId, userName)
        }
    }

    // Unlink student from club
    fun unlinkStudent(student: Student) {
        Log.i("ClubViewModel", "Trying to unlink student -> ${student.userName}")

        _state.value.club?.let { club ->
            clubManager.unLinkStudent(student, club)
        }
    }
}

// State data class holding current club and its classes
data class ClubState(
    val club: ClubComplete? = null,
    val classes: List<Class> = emptyList(),
    val finishedClasses: List<Class> = emptyList()
)

// UI state for club loading
sealed interface ClubUiState {
    data object Success : ClubUiState
    data object Loading : ClubUiState
}

// UI state for classes loading
sealed interface ClubClassUiState {
    data object Success : ClubClassUiState
    data object Loading : ClubClassUiState
}