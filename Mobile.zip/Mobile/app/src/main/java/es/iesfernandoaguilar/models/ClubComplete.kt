package es.iesfernandoaguilar.models

data class ClubComplete(
    override val id: Long,
    override val name: String,
    override val havePhoto: Boolean,
    override val photo: ByteArray?,
    val cif: String,
    override val description: String,
    override val address: String,
    override val city: String,
    override val postalCode: String,
    val canManage: Boolean,
    val students: List<Student>
) : Club(id, name, description, havePhoto, photo, address, city, postalCode)