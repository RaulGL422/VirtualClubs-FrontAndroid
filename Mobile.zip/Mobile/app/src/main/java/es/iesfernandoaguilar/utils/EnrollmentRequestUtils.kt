package es.iesfernandoaguilar.utils

import es.iesfernandoaguilar.models.EnrollmentRequest
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object EnrollmentRequestUtils {

    // Deserialize a single enrollment request from a formatted string
    private fun deserializeEnrollmentRequest(request: String): EnrollmentRequest {
        val trimmed = request.removePrefix("{").removeSuffix("}")

        // Find the index where the class data starts (marked by ",{")
        val classStartIndex = trimmed.indexOf(",{")

        // Extract the ID and date parts from the start of the string
        val initialParts = trimmed.substring(0, classStartIndex).split(",", limit = 2)

        val id = initialParts[0].toLong()
        val date = LocalDateTime.parse(initialParts[1], DateTimeFormatter.ISO_LOCAL_DATE_TIME)

        // Extract the class data string and deserialize it
        val classStr = trimmed.substring(classStartIndex + 1)
        val clazz = ClassUtils.deserializeClass(classStr)

        return EnrollmentRequest(id, clazz, date)
    }

    // Deserialize a list of enrollment requests from a raw string
    fun deserializeEnrollmentRequestList(requestList: String): List<EnrollmentRequest> {
        val trimmed = requestList.removePrefix("{").removeSuffix("}")

        // Return empty list if input is blank
        if (trimmed.isBlank()) return emptyList()

        // Split the string by individual enrollment requests and deserialize each one
        return trimmed.split("},{").map {
            val formatted = "{" + it.removePrefix("{").removeSuffix("}") + "}"
            deserializeEnrollmentRequest(formatted)
        }
    }
}
