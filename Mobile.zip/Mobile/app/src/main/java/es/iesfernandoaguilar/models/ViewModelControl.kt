package es.iesfernandoaguilar.models

interface ViewModelControl