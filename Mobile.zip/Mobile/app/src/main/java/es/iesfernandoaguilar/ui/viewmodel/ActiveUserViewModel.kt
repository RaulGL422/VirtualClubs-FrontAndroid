package es.iesfernandoaguilar.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.models.ViewModelControl
import es.iesfernandoaguilar.models.objects.ErrorHandler
import es.iesfernandoaguilar.models.objects.ViewModelActive
import es.iesfernandoaguilar.ui.manager.UserManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class ActiveUserViewModel @Inject constructor(
    private val userManager: UserManager
) : ViewModelControl, ViewModel() {

    private val _state = MutableStateFlow(ActiveUserState())
    val state: StateFlow<ActiveUserState> = _state.asStateFlow()

    init {
        ViewModelActive.setActive(this)
    }

    fun onCodeChanged(newCode: String) {
        _state.value = _state.value.copy(code = newCode)
    }

    fun sendCode() {
        val code = _state.value.code
        if (code.isBlank()) {
            ErrorHandler.showError(R.string.code_cant_be_empty)
            return
        }

        Log.i("ActiveUserViewModel", "Sending activation code: $code")
        userManager.sendCode(code)
    }

    fun requestNewCode() {
        Log.i("ActiveUserViewModel", "Requesting a new activation code.")
        userManager.requestUserActiveCode()
    }
}

data class ActiveUserState(
    val code: String = ""
)
