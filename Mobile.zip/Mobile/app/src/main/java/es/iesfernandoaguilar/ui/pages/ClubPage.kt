package es.iesfernandoaguilar.ui.pages

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import es.iesfernandoaguilar.R
import es.iesfernandoaguilar.models.Class
import es.iesfernandoaguilar.ui.ScreenType
import es.iesfernandoaguilar.ui.components.AppBar
import es.iesfernandoaguilar.ui.navigation.Destination
import es.iesfernandoaguilar.ui.viewmodel.ClubClassUiState
import es.iesfernandoaguilar.ui.viewmodel.ClubUiState
import es.iesfernandoaguilar.ui.viewmodel.ClubViewModel

object ClubDestination : Destination {
    override val route = "club"
    override val titleRes = -1
}

@Composable
fun ClubPage(
    viewModel: ClubViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit,
    onSettingsPressed: () -> Unit,
    onClassSelected: (Class) -> Unit,
    screenType: ScreenType
) {
    // Collect UI states and data from ViewModel
    val clubUiState = viewModel.clubUiState
    val clubClassUiState = viewModel.clubClassUiState
    val clubState by viewModel.state.collectAsState()

    // Determine content width based on screen size
    val contentWidth = when (screenType) {
        ScreenType.Medium -> 0.7f
        ScreenType.Small -> 0.8f
    }

    Scaffold(
        topBar = {
            AppBar(
                canGoBack = true,
                onNavigateBack = onNavigateBack,
                titleResId = R.string.club_page,
                titleString = clubState.club?.name,
                actions = {
                    IconButton(onClick = onSettingsPressed) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = stringResource(id = R.string.settings_page)
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (clubUiState) {
                is ClubUiState.Loading -> {
                    // Show loading spinner while club data loads
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                is ClubUiState.Success -> {
                    val club = clubState.club

                    club?.let {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth(contentWidth)
                                    .fillMaxHeight()
                                    .padding(24.dp)
                                    .verticalScroll(rememberScrollState())
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .defaultMinSize(minHeight = if (it.havePhoto) 200.dp else Dp.Unspecified)
                                ) {
                                    if (it.havePhoto) {
                                        val imageBitmap = remember(it.photo) {
                                            BitmapFactory.decodeByteArray(
                                                it.photo!!, 0, it.photo.size
                                            )?.asImageBitmap()
                                        }
                                        imageBitmap?.let { bitmap ->
                                            Image(
                                                bitmap = bitmap,
                                                contentDescription = stringResource(R.string.club_photo),
                                                modifier = Modifier
                                                    .fillMaxHeight()
                                                    .weight(0.4f)
                                                    .clip(RoundedCornerShape(8.dp)),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                    }

                                    Column(
                                        modifier = Modifier
                                            .weight(if (it.havePhoto) 0.6f else 1f)
                                            .padding(start = if (it.havePhoto) 16.dp else 0.dp)
                                    ) {
                                        Text(
                                            text = it.name,
                                            style = MaterialTheme.typography.headlineMedium
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        Text(
                                            text = it.description,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }

                                Spacer(Modifier.height(32.dp))

                                // General info section
                                Text(
                                    text = stringResource(R.string.general_information),
                                    style = MaterialTheme.typography.headlineSmall
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(text = stringResource(R.string.cif_value, it.cif))
                                Text(text = stringResource(R.string.address_value, it.address))
                                Text(text = stringResource(R.string.city_value, it.city))
                                Text(text = stringResource(R.string.postal_code_value, it.postalCode))

                                if (it.canManage) {
                                    Spacer(Modifier.height(32.dp))

                                    // Students list
                                    Text(
                                        text = stringResource(R.string.students),
                                        style = MaterialTheme.typography.headlineSmall
                                    )
                                    Spacer(Modifier.height(8.dp))

                                    it.students.forEach { student ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(text = "${student.surName}, ${student.name}")
                                            Button(onClick = { viewModel.unlinkStudent(student) }) {
                                                Text(stringResource(R.string.unlink))
                                            }
                                        }
                                    }

                                    Spacer(Modifier.height(24.dp))

                                    // Invite students section
                                    Text(
                                        text = stringResource(R.string.invite_students),
                                        style = MaterialTheme.typography.headlineSmall
                                    )
                                    Spacer(Modifier.height(8.dp))

                                    var username by remember { mutableStateOf("") }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        TextField(
                                            value = username,
                                            onValueChange = { username = it },
                                            modifier = Modifier.weight(1f),
                                            placeholder = { Text(stringResource(R.string.username)) }
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Button(onClick = {
                                            viewModel.sendRequest(username)
                                            username = ""
                                        }) {
                                            Text(stringResource(R.string.send_invitation))
                                        }
                                    }

                                    Spacer(Modifier.height(32.dp))

                                    // Classes section
                                    Text(
                                        text = stringResource(R.string.classes),
                                        style = MaterialTheme.typography.headlineSmall
                                    )

                                    when (clubClassUiState) {
                                        ClubClassUiState.Loading -> {
                                            Box(
                                                modifier = Modifier.fillMaxSize(),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator()
                                            }
                                        }
                                        ClubClassUiState.Success -> {
                                            ClassListSection(
                                                classList = clubState.classes,
                                                finishedClassList = clubState.finishedClasses,
                                                onClassSelected = onClassSelected,
                                                limitHeight = 300.dp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
