package es.iesfernandoaguilar.ui

import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import es.iesfernandoaguilar.ui.navigation.AppNavHost


@Composable
fun TFGMainApp(
    windowSize: WindowWidthSizeClass,
    navController: NavHostController = rememberNavController()
) {
    // Create the screen type
    val screenType = when (windowSize) {
        WindowWidthSizeClass.Compact, WindowWidthSizeClass.Medium -> ScreenType.Small
        WindowWidthSizeClass.Expanded -> ScreenType.Medium
        else -> ScreenType.Medium
    }

    // Initialize Nav Host
    AppNavHost(navController, screenType)
}

// Enum for screen types based on window size.
enum class ScreenType {
    Small,
    Medium
}