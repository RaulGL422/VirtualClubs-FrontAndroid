package es.iesfernandoaguilar.utils

import es.iesfernandoaguilar.models.Student

object UserUtils {

    // Deserialize a single user string into a Student object
    private fun deserializeUser(user: String): Student {
        val trimmed = user.trim().removePrefix("{").removeSuffix("}")
        val parts = trimmed.split(",")
        return Student(
            parts[0].toLong(),
            parts[1],
            parts[2],
            parts[3],
            parts[4]
        )
    }

    // Deserialize a list of users from a string
    fun deserializeUserList(users: String): List<Student> {
        val trimmed = users.trim().removePrefix("{").removeSuffix("}")
        if (trimmed.isBlank()) return emptyList()

        // Split string into individual user strings
        val studentStrings = trimmed.split("},{").map {
            "{" + it.removePrefix("{").removeSuffix("}") + "}"
        }

        // Convert each string to Student
        return studentStrings.map { deserializeUser(it) }
    }
}
