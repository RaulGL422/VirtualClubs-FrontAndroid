package es.iesfernandoaguilar.utils

import es.iesfernandoaguilar.models.Club

object ClubSerializerUtils {

    // Deserialize a single club string into a Club object
    suspend fun deserializeClub(clubString: String, onRequestClubPhoto: suspend (Int) -> ByteArray): Club {
        val content = clubString.removePrefix("{").removeSuffix("}")
        val parts = StringUtils.smartSplit(content)

        require(parts.size == 8) { "Invalid club format" }

        val id = parts[0].toLong()
        val name = parts[1].removeSurrounding("\"")
        val description = parts[2].removeSurrounding("\"")
        val havePhoto = parts[3] == "1"
        val port = parts[4].toIntOrNull()
        val address = parts[5]
        val city = parts[6]
        val postalCode = parts[7]

        val photo = if (havePhoto && port != null) {
            onRequestClubPhoto(port)
        } else null

        return Club(
            id = id,
            name = name,
            description = description,
            havePhoto = havePhoto,
            photo = photo,
            address = address,
            city = city,
            postalCode = postalCode
        )
    }

    // Deserialize a list of clubs from a string.
    suspend fun deserializeClubList(clubStringList: String, onRequestClubPhoto: suspend (Int) -> ByteArray): List<Club> {
        if (clubStringList.isBlank()) return emptyList()

        val content = clubStringList.removePrefix("{").removeSuffix("}")

        // Split at '},' but keep the '}' in the previous element to preserve the format
        val clubStrings = content.split(Regex("(?<=\\}),")).map { it.trim() }

        return clubStrings.filter { it.isNotEmpty() }.map {
            deserializeClub(it, onRequestClubPhoto)
        }
    }
}
