package es.iesfernandoaguilar.utils

import es.iesfernandoaguilar.models.enums.TypeMessage
import es.iesfernandoaguilar.models.network.Message

object Serializator {

    // Serialize a Message object into a semicolon-separated string
    fun serialize(message: Message): String {
        return "${message.type};${message.args.joinToString(";")}"
    }

    // Deserialize a semicolon-separated string into a Message object
    fun deserialize(message: String): Message {
        val split = message.split(";")
        val type = TypeMessage.valueOf(split[0])
        val args = split.subList(1, split.size).toList()
        return Message(type, args)
    }
}
