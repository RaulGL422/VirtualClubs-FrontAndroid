package es.iesfernandoaguilar.models

data class User(
    val userName: String,
    val email: String
)
